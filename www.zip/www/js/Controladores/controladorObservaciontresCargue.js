angular.module('starter.controladorobservaciontrescargue', [])

.controller('Observaciontrescargue', function($scope, $ionicLoading, factoryObservaciones)
{
	$scope.obs3cargue = factoryObservaciones.totalObservaciones;
    angular.element(document).ready(function () 
    {
    	if ($scope.obs3cargue.length == 0) 
    	{
			dbShell.transaction( function(tx) 
			{            
				tx.executeSql("SELECT * FROM Observaciones", [],                
				
				function(tx, result)
				{              
					for(var i=1; i < result.rows.length; i++) 
					{
						var id = i;
						var idObs = result.rows.item(i)['IdObservacion'];
						var nombreObs = result.rows.item(i)['NombreObservacion'];

						$scope.newObs3Cargue =
						{
							id: id,
							idObs: idObs,
							nombreObs: nombreObs
						};

						$scope.obs3cargue.push($scope.newObs3Cargue);
					}               
				});    
			});
		}
		else
		{
			$scope.obs3cargue = factoryObservaciones.totalObservaciones;
		}
    });


	$scope.mostrarObs3Cargue = function(a)
	{
		var idObservacion3Cargue = $scope.obs3cargue[a-1].idObs;
		$('#txtCodObservacion3Cargue').val(idObs);
		var nombreObservacion3Cargue = $scope.obs3cargue[a-1].nombreObs;
		$('#txtNomObservacion3Cargue').val(nombreObs);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob3cargue"+a).css("background-color", "#ef473a");
		$("#ob3cargue"+a + " div").css("color", "#FFF");
		$("#ob3cargue"+a + " div").css("font-weight", "bold");
	}
});