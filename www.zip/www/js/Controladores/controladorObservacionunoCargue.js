angular.module('starter.controladorobservacionunocargue', [])

.controller('Observacionunocargue', function($scope, $ionicLoading, factoryObservaciones)
{
	$scope.obs1cargue = factoryObservaciones.totalObservaciones;
    angular.element(document).ready(function () 
    {
    	if ($scope.obs1cargue.length == 0) 
    	{
			dbShell.transaction( function(tx) 
			{            
				tx.executeSql("SELECT * FROM Observaciones", [],                
				
				function(tx, result)
				{                  
					for(var i=1; i < result.rows.length; i++) 
					{
						var idCargue = i;
						var idObservacion1Cargue = result.rows.item(i)['IdObservacion'];
						var nombreObservacion1Cargue = result.rows.item(i)['NombreObservacion'];

						$scope.newObs1Cargue =
						{
							idCargue: idCargue,
							idObservacion1Cargue: idObservacion1Cargue,
							nombreObservacion1Cargue: nombreObservacion1Cargue
						};

						$scope.obs1cargue.push($scope.newObs1Cargue);
					}               
				});    
			});
		}

		else
		{
			$scope.obs1cargue = factoryObservaciones.totalObservaciones;
		}
    });


	$scope.mostrarObs1cargue = function(a)
	{
		var idObservacion1Cargue = $scope.obs1cargue[a-1].idObservacion1Cargue;;
		$('#txtCodObservacionCargue').val(idObservacion1Cargue);
		var nombreObservacion1Cargue = $scope.obs1cargue[a-1].nombreObservacion1Cargue;
		$('#txtNomObservacionCargue').val(nombreObservacion1Cargue);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob1cargue"+a).css("background-color", "#ef473a");
		$("#ob1cargue"+a + " div").css("color", "#FFF");
		$("#ob1cargue"+a + " div").css("font-weight", "bold");
	}
});