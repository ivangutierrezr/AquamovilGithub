angular.module('starter.controladorcausales', [])

.controller('Causales', function($scope, $ionicLoading, factoryCausales)
{
	$scope.causal = factoryCausales.totalCausales;
    angular.element(document).ready(function () 
    {
    	if ($scope.causal.length == 0) 
    	{
    		dbShell.transaction( function(tx) 
			{            
				tx.executeSql("SELECT * FROM Causales", [],                
				
				function(tx, result)
				{                 
					for(var i=1; i < result.rows.length; i++) 
					{   
						var id = i;
						var idCausal = result.rows.item(i)['IdCausal'];
						var nombreCausal = result.rows.item(i)['NombreCausal'];

						$scope.newCausal = 
						{
							id: id,
							idCausal: idCausal,
							nombreCausal: nombreCausal
						};

						$scope.causal.push($scope.newCausal);
					}               
				});    
			});
    	}
    });

	$scope.mostrarCausal = function(a)
	{
		var idCausal = $scope.causal[a-1].idCausal;
		$('#txtCodCausal').val(idCausal);
		var nombreCausal = $scope.causal[a-1].nombreCausal;
		$('#txtNomCausal').val(nombreCausal);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#c"+a).css("background-color", "#ef473a");
		$("#c"+a + " div").css("color", "#FFF");
		$("#c"+a + " div").css("font-weight", "bold");
	}
});
 
