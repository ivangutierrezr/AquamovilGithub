angular.module('starter.controladorobservaciondoscargue', [])

.controller('Observaciondoscargue', function($scope, $ionicLoading, factoryObservaciones)
{
	$scope.obs2cargue = factoryObservaciones.totalObservaciones;
    angular.element(document).ready(function () 
    {
    	if ($scope.obs2cargue.length == 0) 
    	{
			dbShell.transaction( function(tx) 
			{            
				tx.executeSql("SELECT * FROM Observaciones", [],                
				
				function(tx, result)
				{              
					for(var i=1; i < result.rows.length; i++) 
					{
						var id2Cargue = i;
						var idObservacion2Cargue = result.rows.item(i)['IdObservacion'];
						var nombreObservacion2Cargue = result.rows.item(i)['NombreObservacion'];

						$scope.newObs2Cargue =
						{
							id2Cargue: id2Cargue,
							idObservacion2Cargue: idObservacion2Cargue,
							nombreObservacion2Cargue: nombreObservacion2Cargue
						};

						$scope.obs2cargue.push($scope.newObs2Cargue);
					}               
				});    
			});
		}

		else
		{
			$scope.obs2cargue = factoryObservaciones.totalObservaciones;
		}
    });


	$scope.mostrarObs2Cargue = function(a)
	{
		var idObservacion2Cargue = $scope.obs2cargue[a-1].idObservacion2Cargue;
		$('#txtCodObservacion2Cargue').val(idObservacion2Cargue);
		var nombreObservacion2Cargue = $scope.obs2cargue[a-1].nombreObservacion2Cargue;
		$('#txtNomObservacion2Cargue').val(nombreObservacion2Cargue);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob2cargue"+a).css("background-color", "#ef473a");
		$("#ob2cargue"+a + " div").css("color", "#FFF");
		$("#ob2cargue"+a + " div").css("font-weight", "bold");
	}
});