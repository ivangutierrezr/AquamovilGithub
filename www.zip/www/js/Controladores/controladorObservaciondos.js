angular.module('starter.controladorobservaciondos', [])

.controller('Observaciondos', function($scope, $ionicLoading, factoryObservaciones)
{
	$scope.obs2 = factoryObservaciones.totalObservaciones;
    angular.element(document).ready(function () 
    {
    	if ($scope.obs2.length == 0) 
    	{
			dbShell.transaction( function(tx) 
			{            
				tx.executeSql("SELECT * FROM Observaciones", [],                
				
				function(tx, result)
				{              
					for(var i=1; i < result.rows.length; i++) 
					{
						var id2 = i;
						var idObservacion2 = result.rows.item(i)['IdObservacion'];
						var nombreObservacion2 = result.rows.item(i)['NombreObservacion'];

						$scope.newObs2 =
						{
							id2: id2,
							idObservacion2: idObservacion2,
							nombreObservacion2: nombreObservacion2
						};

						$scope.obs2.push($scope.newObs2);
					}               
				});    
			});
		}
		else
		{
			$scope.obs2 = factoryObservaciones.totalObservaciones;
		}
    });


	$scope.mostrarObs2 = function(a)
	{
		var idObservacion2 = $scope.obs2[a-1].idObservacion2;
		$('#txtCodObservacion2').val(idObservacion2);
		var nombreObservacion2 = $scope.obs2[a-1].nombreObservacion2;
		$('#txtNomObservacion2').val(nombreObservacion2);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob2"+a).css("background-color", "#ef473a");
		$("#ob2"+a + " div").css("color", "#FFF");
		$("#ob2"+a + " div").css("font-weight", "bold");
	}
});