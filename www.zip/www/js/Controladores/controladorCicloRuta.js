angular.module('starter.controladorcicloruta', [])

.controller('Cicloruta', function($scope, $ionicLoading)
{
	$scope.listacicloruta = [];
    angular.element(document).ready(function () 
    {
    	console.log('lanzado desde CicloRuta');
    	var idbd = document.getElementById("idOperario").value;
    	dbShell.transaction( function(tx) 
		{            
			tx.executeSql("SELECT * FROM AsignacionRutas where Oper=?", [idbd],                
			function(tx, result)
			{                  
				for(var i=0; i < result.rows.length; i++) 
				{   
					if(result.rows.length != 0)
					{
						var numDato = 0;
						var ciclo = result.rows.item(i)['Ciclo'];
						var ruta = result.rows.item(i)['Ruta'];             
						
						$scope.newCR =
						{
							numDato: numDato,
							ciclo: ciclo,
							ruta: ruta
						};

						$scope.listacicloruta.push($scope.newCR);
						$("#inputControlCR").val($scope.listacicloruta.length);
					}
					
					else
					{
						swal("Atención", "Usted no tiene permisos para efectuar lecturas", "error");
					}
				}              
			});    
		});
    });

	/*----------------------------------------------------------------------------------*/

	//Mostrar el primer dato de lectura

	$scope.primeraLectura = function(ciclo,ruta,a)
	{
		var dato = a;
		console.log(dato); 
		dbShell.transaction(function(tx) 
		{ 	
			tx.executeSql("select * FROM UsuariosServicios where Ciclo=? and Ruta=?",[ciclo,ruta], 
			function(tx,result)
			{
				if(result.rows.length == 0)
				{
					swal("Atención","No existen registros con el Ciclo y Ruta seleccionados","error");
					window.location.href = "#/cicloruta"
				}

				if(result.rows.length > 0)
				{
					var LectActual = parseInt(result.rows.item(dato)['LecturaActual']);
					var CauActual = parseInt(result.rows.item(dato)['CausalActual']);
					var ciclo2 = parseInt(result.rows.item(dato)['Ciclo']);
					var ruta2 = parseInt(result.rows.item(dato)['Ruta']);

					if((LectActual >= 0 || CauActual > 0) && dato <= result.rows.length - 2)
					{
						var num = dato + 1;
						$scope.primeraLectura(ciclo2,ruta2,num);
					}

					else
					{
						MostrarPrimeraLectura(ciclo2,ruta2,dato);
					}
				}
			});
		});	
	}

	function MostrarPrimeraLectura(ciclo,ruta,a)
	{
		var dato = a;
		console.log(dato);
		dbShell.transaction(function(tx) 
		{ 	
			tx.executeSql("select * FROM UsuariosServicios where Ciclo=? and Ruta=?",[ciclo,ruta], 
			function(tx,result)
			{
				if(result.rows.length > 0)
				{
					var RegSig = dato + 1;
					var RegAnt = dato - 1;

					if(dato == 0)
					{
						document.getElementById('txtIdUsuarioLecturaAnt').value = " ";
						$("#btnSig i").removeClass("disable");
						$("#btnSig span").removeClass("disable");
						$("#btnAnt span").addClass("disable");
						$("#btnAnt i").addClass("disable");
						$("#btnSig").attr("onClick", "ContarLecturas()");
						$("#btnAnt").attr("onClick", " ");

						var ConsecSig = result.rows.item(RegSig)['Consecutivo'];
						document.getElementById('txtIdUsuarioLecturaSig').value = "Siguiente: " + result.rows.item(RegSig)['IdUsuario'] + ": " + ciclo + "-" + ruta + "-" + ConsecSig;
					}

					if(dato == result.rows.length-1)
					{
						document.getElementById('txtIdUsuarioLecturaSig').value = " ";
						$("#btnSig i").addClass("disable");
						$("#btnSig span").addClass("disable");
						$("#btnAnt span").removeClass("disable");
						$("#btnAnt i").removeClass("disable");
						$("#btnSig").attr("onClick", " ");
						$("#btnAnt").attr("onClick", "validarLectAnt()");

						var ConsecAnt = result.rows.item(RegAnt)['Consecutivo'];

						document.getElementById('txtIdUsuarioLecturaAnt').value = "Anterior: " + result.rows.item(RegAnt)['IdUsuario'] + ": " + ciclo + "-" + ruta + "-" + ConsecAnt;
					}

					if(dato > 0 && dato <= result.rows.length-2)
					{
						var ConsecAnt = result.rows.item(RegAnt)['Consecutivo'];
						var ConsecSig = result.rows.item(RegSig)['Consecutivo'];

						$("#btnSig i").removeClass("disable");
						$("#btnSig span").removeClass("disable");
						$("#btnAnt span").removeClass("disable");
						$("#btnAnt i").removeClass("disable");
						$("#btnSig").attr("onClick", "ContarLecturas()");
						$("#btnAnt").attr("onClick", "validarLectAnt()");

						document.getElementById('txtIdUsuarioLecturaAnt').value = "Anterior: " + result.rows.item(RegAnt)['IdUsuario'] + ": " + ciclo + "-" + ruta + "-" + ConsecAnt;

						document.getElementById('txtIdUsuarioLecturaSig').value = "Siguiente: " + result.rows.item(RegSig)['IdUsuario'] + ": " + ciclo + "-" + ruta + "-" + ConsecSig;			
					}

					ContarRegistros(ciclo,ruta);

					document.getElementById("txtIdOperario").innerHTML = document.getElementById("nombreOperario").value;

					document.getElementById('txtNumRegistro').value = dato;
					document.getElementById('txtNumero').value = result.rows.item(dato)['Numero'];
					document.getElementById('txtIdUsuarioLectura').value = result.rows.item(dato)['IdUsuario'];
					document.getElementById('txtidUsuarioLecturaCtrl').value = result.rows.item(dato)['IdUsuario'];

					var Ciclotx = result.rows.item(dato)['Ciclo'];	
					document.getElementById('txtCiclo').value = Ciclotx;
					document.getElementById('txtCiclo2').value = "Ciclo: " + Ciclotx;

					var Rutatx = result.rows.item(dato)['Ruta'];
					document.getElementById('txtRuta').value = Rutatx;
					document.getElementById('txtRuta2').value = "Ruta: " + Rutatx;
					
					document.getElementById('txtCRC').value = result.rows.item(dato)['Consecutivo'];					
					document.getElementById("txtCicloNuevo").value = result.rows.item(dato)['CicloNuevo'];
					document.getElementById("txtRutaNueva").value = result.rows.item(dato)['RutaNueva'];
					document.getElementById("txtConsecutivoNuevo").value = result.rows.item(dato)['ConsecutivoNuevo'];
					document.getElementById("txtImpreso").value = result.rows.item(dato)['impreso'];
					document.getElementById("txtEditado").value = result.rows.item(dato)['editado'];
					document.getElementById('txtDireccion').value = result.rows.item(dato)['Direccion'];
					document.getElementById('txtMedidor').value = "MED.# " + result.rows.item(dato)['NumeroMedidor'];					
					document.getElementById('txtTipoMedidor').value = result.rows.item(dato)['TipoMedidor'];
					document.getElementById('consumo').value = result.rows.item(dato)['Consumo'];
					document.getElementById('conceptoCritica').value = result.rows.item(dato)['ConceptoCritica'];

					var IdUsotx = result.rows.item(dato)['IdUso'];

					if(IdUsotx == 1)
					{
						document.getElementById('txtUso').value = "USO: RESIDENCIAL";
					}

					if(IdUsotx == 2)
					{
						document.getElementById('txtUso').value = "USO: COMERCIAL";
					}

					if(IdUsotx == 3)
					{
						document.getElementById('txtUso').value = "USO: INDUSTRIAL";
					}

					if(IdUsotx == 4)
					{
						document.getElementById('txtUso').value = "USO: OFICIAL";
					}

					if(IdUsotx == 5)
					{
						document.getElementById('txtUso').value = "USO: ESPECIAL";
					}

					if(IdUsotx == 6)
					{
						document.getElementById('txtUso').value = "USO: PROVISIONAL";
					}

					document.getElementById('txtCategoria').value = "CATEGORIA: " + result.rows.item(dato)['IdCategoria'];

					var numeroFotostx = result.rows.item(dato)['NumeroFotos'];

					document.getElementById('contadorFotos').value = numeroFotostx;

					//var LecturaAnteriortx = document.getElementById('txtLecturaAnterior').value;
					//LecturaAnteriortx.innerHTML = result.rows.item(dato)['LecturaAnterior'];

					//var ConsumoMediotx = document.getElementById('txtPromedio').value;
					//ConsumoMediotx.innerHTML = result.rows.item(dato)['ConsumoMedio'];

					document.getElementById('txtNombre').value = result.rows.item(dato)['Suscriptor'];
					document.getElementById('txtLectura').value = result.rows.item(dato)['LecturaActual'];
					document.getElementById('txtObservacion2').value = result.rows.item(dato)['ObservacionDos'];
					document.getElementById('txtObservacion3').value = result.rows.item(dato)['ObservacionTres'];
					document.getElementById('txtCausal').value = result.rows.item(dato)['CausalActual'];
					document.getElementById('txtObservacion').value = result.rows.item(dato)['ObservacionActual'];

					if(document.getElementById('txtLectura').value >= 0 || document.getElementById('txtCausal').value >= 1)
					{
						activarImpresion();
						permitirEditar();
					}

					if(document.getElementById('txtLectura').value == '' && document.getElementById('txtCausal').value == 0)
					{
						desactivarImpresion();
						permitirEditar();
					}
				}
			});
		});	
	}

	/*--------------------------------------------------------------------------------*/
	//Funciones para descargar Archivo de Lectura
	 
	$scope.DescargarArchivo = function(cic,rut) 
	{
	    var cicloParaDescargar = cic;
	    var rutaParaDescargar = rut;
	    swal(
	    {
	        title: "Atención",
	        text: "¿Desea descargar Archivo de Lecturas del Ciclo: " + cic + " y Ruta: " + rut +"?, Esto puede tardar varios minutos",
	        type: "warning",
	        showCancelButton: true,
	        confirmButtonColor: "#DD6B55",
	        confirmButtonText: "Si",
	        cancelButtonText: "Cancelar",
	        closeOnConfirm: false,
	        closeOnCancel: false
	    }, 

	    function(isConfirm)
	    {
	        if (isConfirm) 
	        {
	            swal(
	            {
	                title: "Iniciando Descarga",
	                text: "Por favor espere a que el sistema confirme finalización",
	                timer: 100,
	                showConfirmButton: false 
	            });

	            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS, fail); 
	        }

	        else 
	        {
	            swal(
	            {
	                title: "Descarga Cancelada",
	                text: "Regresando",
	                timer: 2000,
	                showConfirmButton: false 
	            });
	        }   
	    });


		function gotFS(fileSystem) 
		{
		    var periodo = document.getElementById("periodoActual").value;

		    while(periodo.length < 3)
		    {
		        periodo = "0" + periodo;
		    }

		    var cic = cicloParaDescargar.toString();
		    var rut = rutaParaDescargar.toString();

		    while(cic.length < 2)
		    {
		        cic = "0" + cic;
		    }

		    while(rut.length < 2)
		    {
		        rut = "0" + rut;
		    }

		    var nombreArchivo = "L" + "" + periodo + "" + cic + "" + rut + "";

		    fileSystem.root.getFile("AQuaMovil/Salidas/" + nombreArchivo + ".csv", {create: true, exclusive: false}, gotFileEntry, fail);
		}

		function gotFileEntry(fileEntry) 
		{
		    fileEntry.createWriter(gotFileWriter, fail);
		}

		function gotFileWriter(writer) 
		{
		    var contador = -1;
		    console.log("Finalizado");
		    writer.onwrite = function(evt) 
		    {
		        console.log("Se escribieron " + contador + "lineas");
		    };

		    writer.onwriteend = function(evt)
		    {
		        contador=contador+1;
		        dbShell.transaction( function(tx) 
		        {            
		            tx.executeSql("SELECT * FROM UsuariosServicios where Ciclo=? and Ruta=?",[cicloParaDescargar,rutaParaDescargar],                
		            function(tx, result)
		            {  
		                if (contador < result.rows.length) 
		                {   
		                    var IdUsuario = result.rows.item(contador)['IdUsuario'];
		                    var Ciclo = result.rows.item(contador)['Ciclo'];
		                    var Ruta = result.rows.item(contador)['Ruta'];
		                    var Consecutivo = result.rows.item(contador)['Consecutivo'];
		                    var Direccion = result.rows.item(contador)['Direccion'];
		                    var NumeroMedidor = result.rows.item(contador)['NumeroMedidor'];
		                    var TipoMedidor = result.rows.item(contador)['TipoMedidor'];
		                    var LecturaAnterior = result.rows.item(contador)['LecturaAnterior'];
		                    var ConsumoMedio = result.rows.item(contador)['ConsumoMedio'];
		                    var Suscriptor = result.rows.item(contador)['Suscriptor'];
		                    var IdUso = result.rows.item(contador)['IdUso'];
		                    var IdCategoria = result.rows.item(contador)['IdCategoria'];
		                    var EdadAcueducto = result.rows.item(contador)['EdadAcueducto'];
		                    var VolumenAseo = result.rows.item(contador)['VolumenAseo'];
		                    var CtasAcR = result.rows.item(contador)['CtasAcR'];
		                    var CtasAcNR = result.rows.item(contador)['CtasAcNR'];
		                    var CtasAlR = result.rows.item(contador)['CtasAlR'];
		                    var CtasAlNR = result.rows.item(contador)['CtasAlNR'];
		                    var CtasAsR = result.rows.item(contador)['CtasAsR'];
		                    var CtasAsNR = result.rows.item(contador)['CtasAsNR'];
		                    var Consumo = result.rows.item(contador)['Consumo'];
							var ConceptoCritica = result.rows.item(contador)['ConceptoCritica'];
							var LecturaActual = result.rows.item(contador)['LecturaActual'];
		                    var CausalActual = result.rows.item(contador)['CausalActual'];
		                    var ObservacionActual = result.rows.item(contador)['ObservacionActual'];
		                    var ObservacionDos = result.rows.item(contador)['ObservacionDos'];
		                    var ObservacionTres = result.rows.item(contador)['ObservacionTres'];
		                    var Fecha = result.rows.item(contador)['Fecha'];
		                    var Hora = result.rows.item(contador)['Hora'];
		                    var latitud = result.rows.item(contador)['latitud'];
		                    var longitud = result.rows.item(contador)['longitud'];
		                    var altura = result.rows.item(contador)['altura'];
		                    var CicloNuevo = result.rows.item(contador)['CicloNuevo'];
		                    var RutaNueva = result.rows.item(contador)['RutaNueva'];
		                    var ConsecutivoNuevo = result.rows.item(contador)['ConsecutivoNuevo'];
		                    var NumeroFotos = result.rows.item(contador)['NumeroFotos'];
		                    var Usuario = result.rows.item(contador)['Usuario'];

		                    var contenidoListaRegistros = IdUsuario + ',' + Ciclo + ',' + Ruta + ',' + Consecutivo + ',' + Direccion + ',' + NumeroMedidor + ',' + TipoMedidor + ',' + LecturaAnterior + ',' + ConsumoMedio + ',' + Suscriptor + ',' + IdUso + ',' + IdCategoria + ',' + Consumo + ',' + ConceptoCritica + ',' + LecturaActual + ',' + CausalActual + ',' + ObservacionActual + ',' + ObservacionDos + ',' + ObservacionTres + ',' + Fecha + ',' + Hora + ',' + latitud + ',' + longitud + ',' + altura + ',' + CicloNuevo + ',' + RutaNueva + ',' + ConsecutivoNuevo + ',' + NumeroFotos + ',' + Usuario + '\r\n';
		                    
		                    var largo = contenidoListaRegistros.length + 1;
		                    writer.write(contenidoListaRegistros);
		                    writer.seek(largo);
		                }
		            });    
		        });
		    swal("Correcto", "Descargadas: " + contador + " lecturas ","success");
		    console.log("Descargadas: " + contador + " lecturas ");
		    };
		    writer.write("");
		}

		function fail(error) {
		    console.log(error.code);
		}
	}
});