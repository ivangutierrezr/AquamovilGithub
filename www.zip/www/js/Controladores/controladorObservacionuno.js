angular.module('starter.controladorobservacionuno', [])

.controller('Observacionuno', function($scope, $ionicLoading, factoryObservaciones)
{
	$scope.obs1 = factoryObservaciones.totalObservaciones;
    angular.element(document).ready(function () 
    {
    	if ($scope.obs1.length == 0) 
    	{
			dbShell.transaction( function(tx) 
			{            
				tx.executeSql("SELECT * FROM Observaciones", [],                
				
				function(tx, result)
				{                  
					for(var i=1; i < result.rows.length; i++) 
					{
						var id = i;
						var idObs = result.rows.item(i)['IdObservacion'];
						var nombreObs = result.rows.item(i)['NombreObservacion'];

						$scope.newObs1 =
						{
							id: id,
							idObs: idObs,
							nombreObs: nombreObs
						};

						$scope.obs1.push($scope.newObs1);
					}               
				});    
			});
		}

		else
		{
			$scope.obs1 = factoryObservaciones.totalObservaciones;
		}
    });


	$scope.mostrarObs1 = function(a)
	{
		var idObservacion1 = $scope.obs1[a-1].idObs;
		$('#txtCodObservacion').val(idObservacion1);
		var nombreObservacion1 = $scope.obs1[a-1].nombreObs;
		$('#txtNomObservacion').val(nombreObservacion1);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob1"+a).css("background-color", "#ef473a");
		$("#ob1"+a + " div").css("color", "#FFF");
		$("#ob1"+a + " div").css("font-weight", "bold");
	}

	$scope.mostrarObs1cargue = function(a)
	{
		var idObservacion1Cargue = $scope.obs1[a-1].idObs;
		$('#txtCodObservacionCargue').val(idObservacion1Cargue);
		var nombreObservacion1Cargue = $scope.obs1[a-1].nombreObs;
		$('#txtNomObservacionCargue').val(nombreObservacion1Cargue);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob1cargue"+a).css("background-color", "#ef473a");
		$("#ob1cargue"+a + " div").css("color", "#FFF");
		$("#ob1cargue"+a + " div").css("font-weight", "bold");
	}

	$scope.mostrarObs2 = function(a)
	{
		var idObservacion2 = $scope.obs1[a-1].idObs;
		$('#txtCodObservacion2').val(idObservacion2);
		var nombreObservacion2 = $scope.obs1[a-1].nombreObs;
		$('#txtNomObservacion2').val(nombreObservacion2);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob2"+a).css("background-color", "#ef473a");
		$("#ob2"+a + " div").css("color", "#FFF");
		$("#ob2"+a + " div").css("font-weight", "bold");
	}

	$scope.mostrarObs2Cargue = function(a)
	{
		var idObservacion2Cargue = $scope.obs1[a-1].idObs;
		$('#txtCodObservacion2Cargue').val(idObservacion2Cargue);
		var nombreObservacion2Cargue = $scope.obs1[a-1].nombreObs;
		$('#txtNomObservacion2Cargue').val(nombreObservacion2Cargue);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob2cargue"+a).css("background-color", "#ef473a");
		$("#ob2cargue"+a + " div").css("color", "#FFF");
		$("#ob2cargue"+a + " div").css("font-weight", "bold");
	}

	$scope.mostrarObs3 = function(a)
	{
		var idObservacion3 = $scope.obs1[a-1].idObs;
		$('#txtCodObservacion3').val(idObservacion3);
		var nombreObservacion3 = $scope.obs1[a-1].nombreObs;
		$('#txtNomObservacion3').val(nombreObservacion3);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob3"+a).css("background-color", "#ef473a");
		$("#ob3"+a + " div").css("color", "#FFF");
		$("#ob3"+a + " div").css("font-weight", "bold");
	}

	$scope.mostrarObs3Cargue = function(a)
	{
		var idObservacion3Cargue = $scope.obs1[a-1].idObs;
		$('#txtCodObservacion3Cargue').val(idObs);
		var nombreObservacion3Cargue = $scope.obs1[a-1].nombreObs;
		$('#txtNomObservacion3Cargue').val(nombreObs);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob3cargue"+a).css("background-color", "#ef473a");
		$("#ob3cargue"+a + " div").css("color", "#FFF");
		$("#ob3cargue"+a + " div").css("font-weight", "bold");
	}
});