angular.module('starter.controladorobservaciontres', [])

.controller('Observaciontres', function($scope, $ionicLoading, factoryObservaciones)
{
	$scope.obs3 = factoryObservaciones.totalObservaciones;
    angular.element(document).ready(function () 
    {
    	if ($scope.obs3.length == 0) 
    	{
			dbShell.transaction( function(tx) 
			{            
				tx.executeSql("SELECT * FROM Observaciones", [],                
				
				function(tx, result)
				{              
					for(var i=1; i < result.rows.length; i++) 
					{
						var id3 = i;
						var idObservacion3 = result.rows.item(i)['IdObservacion'];
						var nombreObservacion3 = result.rows.item(i)['NombreObservacion'];

						$scope.newObs3 =
						{
							id3: id3,
							idObservacion3: idObservacion3,
							nombreObservacion3: nombreObservacion3
						};

						$scope.obs3.push($scope.newObs3);
					}               
				});    
			});
		}

		else
		{
			$scope.obs3 = factoryObservaciones.totalObservaciones;
		}
    });


	$scope.mostrarObs3 = function(a)
	{
		var idObservacion3 = $scope.obs3[a-1].idObservacion3;
		$('#txtCodObservacion3').val(idObservacion3);
		var nombreObservacion3 = $scope.obs3[a-1].nombreObservacion3;
		$('#txtNomObservacion3').val(nombreObservacion3);

		$("li").css("background-color", "transparent");
		$("li a div").css("color", "#000");
		$("li a div").css("font-weight", "normal");

		$("#ob3"+a).css("background-color", "#ef473a");
		$("#ob3"+a + " div").css("color", "#FFF");
		$("#ob3"+a + " div").css("font-weight", "bold");
	}
});