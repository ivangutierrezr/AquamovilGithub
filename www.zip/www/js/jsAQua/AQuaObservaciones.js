/*----------------------------------------------------------------------------------*/

//Función para cargar el archivo de Observaciones

function cargarObservaciones(entrada)
{		
	var reader = new FileReader();
	
	reader.onloadend = function(evento)
	{
		var observacion = evento.target.result;
			
		dbShell.transaction(function(tx) 
		{   
			tx.executeSql("select Count(*) as Cantidad from Usuarios  ",[], 
			function(tx, result)
			{				
				var tipoArchivo = typeof result.rows.item(0)['Cantidad'];
				if(1 == 1)
				{
					var Control = observacion.match(/\n/g);
					for(var i = 0; i < Control.length ; i++)
					{						
						var UltimoDato = observacion.indexOf('\n') // Se determina que ";" es salto de linea
						var Dato = observacion.substring(0,UltimoDato);
						var SepararDato = Dato.split(",");  // Se determina que cada dato a incluir en la BD se separa con ","
						
						tx.executeSql("Insert Into Observaciones (IdObservacion, NombreObservacion, exigeFoto, Numero) Values(?,?,?,?)",[
							SepararDato[0],
							SepararDato[1],
							SepararDato[2],
							i]);
						
						observacion=observacion.substring(UltimoDato+1,observacion.length); 
						observacionesSubidas = i+1;
					}
					swal("Cargue Realizado con éxito", "Cargadas " + observacionesSubidas + " Observaciones", "success");

					confimarObservaciones();
				}
			});
		});
	};
	reader.readAsText(entrada);
}

// device APIs are available
//
function Observaciones(){
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFSObservaciones, fail);
}

function gotFSObservaciones(fileSystem) {
    fileSystem.root.getFile("AQuaMovil/Entradas/Observaciones.csv", null, gotFileEntryObservaciones, fail);
}

function gotFileEntryObservaciones(fileEntry) {
    fileEntry.file(gotFileObservaciones, fail);
}

function gotFileObservaciones(file){
    cargarObservaciones(file);
}

/*----------------------------------------------------------------------------------*/
// Borra las observaciones registradas en la base de datos

function borrarObservaciones()
{
	dbShell.transaction(function(tx)
	{
		tx.executeSql("Drop Table Observaciones");
		CrearTablaObservaciones();
		Observaciones();
	});
}

/*----------------------------------------------------------------------------------*/

//Funcion para validar si el usuario ha ingresado observaciones desde la pantalla de lecturas

function validarObservacion()
{
	dbShell.transaction(function(tx) 
	{  
		var numero = document.getElementById("txtNumero").value;

		tx.executeSql("SELECT * FROM UsuariosServicios where Numero=?",[numero], 
		function(tx, result)
		{
			var lect = result.rows.item(0)['LecturaActual'];
			var cau = result.rows.item(0)['CausalActual'];

			console.log(lect);
			console.log(cau);

			if(lect != '' || cau > 0)
			{
				document.getElementById("txtCausal").value = 0;
				document.getElementById("txtObservacion").value = 0;
				document.getElementById("txtObservacion2").value = 0;
				document.getElementById("txtObservacion3").value = 0;
				window.location.href="#/observacionuno";
			}

			else
			{
				var Observacion1 = document.getElementById("txtObservacion").value;
				var Observacion2 = document.getElementById("txtObservacion2").value;

				if(Observacion1 > 0)
				{
					if(Observacion2 > 0)
					{
						window.location.href="#/observaciontres";
					}

					else
					{
						window.location.href="#/observaciondos";
					}
				}
					
				else
				{
					window.location.href="#/observacionuno";
				}
			}
		});
	});
}

/*----------------------------------------------------------------------------------*/
// Verifica que la observación 1 exija foto

function verficarFotoObservacion()
{
	var idObservacion = document.getElementById("txtCodObservacion").value;
	
	dbShell.transaction(function(tx) 
	{
		tx.executeSql("select * from Observaciones Where IdObservacion=? ",[idObservacion], 
			function(tx, result)
		{
			var exFoto = result.rows.item(0)['exigeFoto'];

			if(idObservacion == document.getElementById("txtObservacion2").value || idObservacion == document.getElementById("txtObservacion3").value)
			{
				swal("Atención", "Este Código de Observación ya ha sido ingresado, escoja otro", "warning");
			}

			else
			{
				if(exFoto == "TRUE" || exFoto == "true" || exFoto == "True" || exFoto == "-1" || exFoto == "VERDADERO" || exFoto == "verdadero" || exFoto == "Verdadero" || exFoto == "si" || exFoto == "SI" || exFoto == "Si")
				{
					swal({
						title: "Atencíon!",
						text: "Esta Observación Requiere una foto de evidencia, debe tomar una antes de continuar",
						type: "warning",
						showCancelButton: true,
						confirmButtonColor: "#0088C4",
						confirmButtonText: "Foto",
						cancelButtonText: "Volver",
						closeOnConfirm: true,
						closeOnCancel: false },

						function(isConfirm)
						{
							if (isConfirm) 
							{
						  		FotoObservacion1();
						  	}

						  	else 
						  	{	
						  		swal("Cancelado", "", "error");
						  		document.getElementById("txtObservacion").value = ""; 
							} 
						});
				}

				else
				{
					document.getElementById("txtObservacion").value = idObservacion;
					ActualizarArchivo(); 
				}
			}
		});
	});
}

/*----------------------------------------------------------------------------------*/
// Verifica que la observación 2 exija foto

function verficarFotoObservacion2()
{
	var idObservacion = document.getElementById("txtCodObservacion2").value;
	
	dbShell.transaction(function(tx) 
	{
		tx.executeSql("select * from Observaciones Where IdObservacion=? ",[idObservacion], 
			function(tx, result)
		{
			var exFoto = result.rows.item(0)['exigeFoto'];

			if(idObservacion == document.getElementById("txtObservacion").value || idObservacion == document.getElementById("txtObservacion3").value)
			{
				swal("Atención", "Este Código de Observación ya ha sido ingresado, escoja otro", "warning");
			}

			else
			{
				if(exFoto == "TRUE" || exFoto == "true" || exFoto == "True" || exFoto == "-1" || exFoto == "VERDADERO" || exFoto == "verdadero" || exFoto == "Verdadero" || exFoto == "si" || exFoto == "SI" || exFoto == "Si")
				{
					swal({
						title: "Atencíon!",
						text: "Esta Observación Requiere una foto de evidencia, debe tomar una antes de continuar",
						type: "warning",
						showCancelButton: true,
						confirmButtonColor: "#0088C4",
						confirmButtonText: "Foto",
						cancelButtonText: "Volver",
						closeOnConfirm: true,
						closeOnCancel: false },

						function(isConfirm)
						{
							if (isConfirm) 
							{
						  		FotoObservacion2();
						  	}

						  	else 
						  	{	
						  		swal("Cancelado", "", "error");
						  		document.getElementById("txtObservacion2").value = ""; 
							} 
						});
				}

				else
				{
					document.getElementById("txtObservacion2").value = idObservacion;
					ActualizarArchivo(); 
				}
			}
		});
	});
}

/*----------------------------------------------------------------------------------*/
// Verifica que la observación 3 exija foto


function verficarFotoObservacion3()
{
	var idObservacion = document.getElementById("txtCodObservacion3").value;
	
	dbShell.transaction(function(tx) 
	{
		tx.executeSql("select * from Observaciones Where IdObservacion=? ",[idObservacion], 
			function(tx, result)
		{
			var exFoto = result.rows.item(0)['exigeFoto'];

			if(idObservacion == document.getElementById("txtObservacion").value || idObservacion == document.getElementById("txtObservacion2").value)
			{
				swal("Atención", "Este Código de Observación ya ha sido ingresado, escoja otro", "warning");
			}

			else
			{
				if(exFoto == "TRUE" || exFoto == "true" || exFoto == "True" || exFoto == "-1" || exFoto == "VERDADERO" || exFoto == "verdadero" || exFoto == "Verdadero" || exFoto == "si" || exFoto == "SI" || exFoto == "Si")
				{
					swal({
						title: "Atencíon!",
						text: "Esta Observación Requiere una foto de evidencia, debe tomar una antes de continuar",
						type: "warning",
						showCancelButton: true,
						confirmButtonColor: "#0088C4",
						confirmButtonText: "Foto",
						cancelButtonText: "Volver",
						closeOnConfirm: true,
						closeOnCancel: false },

						function(isConfirm)
						{
							if (isConfirm) 
							{
						  		FotoObservacion3();
						  	}

						  	else 
						  	{	
						  		swal("Cancelado", "", "error");
						  		document.getElementById("txtObservacion3").value = "";
							} 
						});
				}

				else
				{
					document.getElementById("txtObservacion3").value = idObservacion;
					ActualizarArchivo();
				}
			}
		});
	});
}

/*----------------------------------------------------------------------------------*/
// Verifica que la observación 1 ingresada desde el menu de Cargue exija foto

function verficarFotoObservacion4()
{
	var idObservacion = document.getElementById("txtCodObservacionCargue").value;
	
	dbShell.transaction(function(tx) 
	{
		tx.executeSql("select * from Observaciones Where IdObservacion=? ",[idObservacion], 
			function(tx, result)
		{
			var exFoto = result.rows.item(0)['exigeFoto'];

			if(idObservacion == document.getElementById("txtObservacion2").value || idObservacion == document.getElementById("txtObservacion3").value)
			{
				swal("Atención", "Este Código de Observación ya ha sido ingresado, escoja otro", "warning");
			}

			else
			{
				if(exFoto == "TRUE" || exFoto == "true" || exFoto == "True" || exFoto == "-1" || exFoto == "VERDADERO" || exFoto == "verdadero" || exFoto == "Verdadero" || exFoto == "si" || exFoto == "SI" || exFoto == "Si")
				{
					swal({
						title: "Atencíon!",
						text: "Esta Observación Requiere una foto de evidencia, debe tomar una antes de continuar",
						type: "warning",
						showCancelButton: true,
						confirmButtonColor: "#0088C4",
						confirmButtonText: "Foto",
						cancelButtonText: "Volver",
						closeOnConfirm: true,
						closeOnCancel: false },

						function(isConfirm)
						{
							if (isConfirm) 
							{
						  		FotoObservacion4();
						  	}

						  	else 
						  	{	
						  		swal("Cancelado", "", "error");
						  		document.getElementById("txtObservacion").value = ""; 
							} 
						});
				}

				else
				{
					validarNuevaObs1(idObservacion);
				}
			}
		});
	});
}

function validarNuevaObs1(idObservacion)
{
	dbShell.transaction(function(tx) 
	{  
		var numero = document.getElementById("txtNumero").value;
		var obs = idObservacion;

		tx.executeSql("SELECT * FROM UsuariosServicios where Numero=?",[numero], 
		function(tx, result)
		{
			var lect = result.rows.item(0)['LecturaActual'];
			var cau = result.rows.item(0)['CausalActual'];

			if(lect != '' || cau > 0)
			{
				ActualizarObs1(obs);
			}
			else
			{
				document.getElementById("txtObservacion").value = obs;
				window.location.href= "#/medidorlecturas";
			}
		});
	});
}

function ActualizarObs1(obs)
{
	var numero = document.getElementById("txtNumero").value;
	dbShell.transaction(function(tx) 
	{
		console.log(obs);
		tx.executeSql("Update UsuariosServicios set ObservacionActual=? where Numero=?",[obs,numero], 

		function(tx, result)
		{
			document.getElementById("txtObservacion").value = obs;
			window.location.href= "#/medidorlecturas";
		});
	});
}


/*----------------------------------------------------------------------------------*/
// Verifica que la observación 2 ingresada desde el menu de Cargue exija foto

function verficarFotoObservacion5()
{
	var idObservacion = document.getElementById("txtCodObservacion2Cargue").value;
	
	dbShell.transaction(function(tx) 
	{
		tx.executeSql("select * from Observaciones Where IdObservacion=? ",[idObservacion], 
			function(tx, result)
		{
			var exFoto = result.rows.item(0)['exigeFoto'];

			if(idObservacion == document.getElementById("txtObservacion").value || idObservacion == document.getElementById("txtObservacion3").value)
			{
				swal("Atención", "Este Código de Observación ya ha sido ingresado, escoja otro", "warning");
			}

			else
			{
				if(exFoto == "TRUE" || exFoto == "true" || exFoto == "True" || exFoto == "-1" || exFoto == "VERDADERO" || exFoto == "verdadero" || exFoto == "Verdadero" || exFoto == "si" || exFoto == "SI" || exFoto == "Si")
				{
					swal({
						title: "Atencíon!",
						text: "Esta Observación Requiere una foto de evidencia, debe tomar una antes de continuar",
						type: "warning",
						showCancelButton: true,
						confirmButtonColor: "#0088C4",
						confirmButtonText: "Foto",
						cancelButtonText: "Volver",
						closeOnConfirm: true,
						closeOnCancel: false },

						function(isConfirm)
						{
							if (isConfirm) 
							{
						  		FotoObservacion5();
						  	}

						  	else 
						  	{	
						  		swal("Cancelado", "", "error");
						  		document.getElementById("txtObservacion2").value = "";  
							} 
						});
				}

				else
				{
					validarNuevaObs2(idObservacion);
					document.getElementById("txtObservacion2").value = idObservacion;
					window.location.href= "#/medidorlecturas";
				}
			}
		});
	});
}

function validarNuevaObs2(idObservacion)
{
	dbShell.transaction(function(tx) 
	{  
		var numero = document.getElementById("txtNumero").value;
		var obs = idObservacion;

		tx.executeSql("SELECT * FROM UsuariosServicios where Numero=?",[numero], 
		function(tx, result)
		{
			var lect = result.rows.item(0)['LecturaActual'];
			var cau = result.rows.item(0)['CausalActual'];

			console.log(lect);
			console.log(cau);

			if(lect != '' || cau > 0)
			{
				console.log('Lanzada');
				ActualizarObs2(obs);
			}
			else
			{
				document.getElementById("txtObservacion2").value = obs;
				window.location.href= "#/medidorlecturas";
			}
		});
	});
}

function ActualizarObs2(obs)
{
	var numero = document.getElementById("txtNumero").value;
	dbShell.transaction(function(tx) 
	{
		console.log(obs);
		tx.executeSql("Update UsuariosServicios set ObservacionDos=? where Numero=?",[obs,numero], 

		function(tx, result)
		{
			document.getElementById("txtObservacion2").value = obs;
			window.location.href= "#/medidorlecturas";
		});
	});
}

/*----------------------------------------------------------------------------------*/
// Verifica que la observación 2 ingresada desde el menu de Cargue exija foto

function verficarFotoObservacion6()
{
	var idObservacion = document.getElementById("txtCodObservacion3Cargue").value;
	
	dbShell.transaction(function(tx) 
	{
		tx.executeSql("select * from Observaciones Where IdObservacion=? ",[idObservacion], 
			function(tx, result)
		{
			var exFoto = result.rows.item(0)['exigeFoto'];

			if(idObservacion == document.getElementById("txtObservacion").value || idObservacion == document.getElementById("txtObservacion2").value)
			{
				swal("Atención", "Este Código de Observación ya ha sido ingresado, escoja otro", "warning");
			}

			else
			{
				if(exFoto == "TRUE" || exFoto == "true" || exFoto == "True" || exFoto == "-1" || exFoto == "VERDADERO" || exFoto == "verdadero" || exFoto == "Verdadero" || exFoto == "si" || exFoto == "SI" || exFoto == "Si")
				{
					swal({
						title: "Atencíon!",
						text: "Esta Observación Requiere una foto de evidencia, debe tomar una antes de continuar",
						type: "warning",
						showCancelButton: true,
						confirmButtonColor: "#0088C4",
						confirmButtonText: "Foto",
						cancelButtonText: "Volver",
						closeOnConfirm: true,
						closeOnCancel: false },

						function(isConfirm)
						{
							if (isConfirm) 
							{
						  		FotoObservacion6();
						  	}

						  	else 
						  	{	
						  		swal("Cancelado", "", "error");
						  		document.getElementById("txtObservacion3").value = "";
							} 
						});
				}

				else
				{
					validarNuevaObs3(idObservacion);
				}
			}
		});
	});
}

function validarNuevaObs3(idObservacion)
{
	dbShell.transaction(function(tx) 
	{  
		var numero = document.getElementById("txtNumero").value;
		var obs = idObservacion;

		tx.executeSql("SELECT * FROM UsuariosServicios where Numero=?",[numero], 
		function(tx, result)
		{
			var lect = result.rows.item(0)['LecturaActual'];
			var cau = result.rows.item(0)['CausalActual'];

			if(lect != '' || cau > 0)
			{
				ActualizarObs3(obs);
			}
			else
			{
				document.getElementById("txtObservacion3").value = obs;
				window.location.href= "#/medidorlecturas";
			}
		});
	});
}

function ActualizarObs3(obs)
{
	var numero = document.getElementById("txtNumero").value;
	dbShell.transaction(function(tx) 
	{
		console.log(obs);
		tx.executeSql("Update UsuariosServicios set ObservacionTres=? where Numero=?",[obs,numero], 

		function(tx, result)
		{
			document.getElementById("txtObservacion3").value = obs;
			window.location.href= "#/medidorlecturas";
		});
	});
}