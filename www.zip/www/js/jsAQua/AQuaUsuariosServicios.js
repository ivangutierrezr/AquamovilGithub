/*----------------------------------------------------------------------------------*/

//Función para cargar lecturas

function cargarUsuariosServicios(entrada)
{	
	var reader = new FileReader();
	
	reader.onloadend=function(evento)
	{
		var UsuariosServicios = evento.target.result;			
		dbShell.transaction(function(tx) 
		{   
			tx.executeSql("select Count(*) as Cantidad  from Usuarios  ",[], 
			function(tx, result)
			{				
				var tipoArchivo= typeof result.rows.item(0)['Cantidad'];
				if(1 == 1)
				{
					var Control = UsuariosServicios.match(/\n/g);
					for(var i = 0; i < Control.length ; i++)
					{						
						var UltimoDato = UsuariosServicios.indexOf('\n'); // Se determina que "/n" es salto de linea
						var Dato = UsuariosServicios.substring(0,UltimoDato);
						var SepararDato = Dato.split(','); // Se determina que cada dato a incluir en la BD se separa con ","
						
						tx.executeSql("Insert Into UsuariosServicios (Numero, IdUsuario, Ciclo, Ruta, Consecutivo, Direccion, NumeroMedidor, TipoMedidor, LecturaAnterior, ConsumoMedio, Suscriptor, IdUso, IdCategoria, EdadAcueducto, VolumenAseo, CtasAcR, CtasAcNR, CtasAlR, CtasAlNR, CtasAsR, CtasAsNR, UltimaFechaDeFacturacion, Consumo, ConceptoCritica, LecturaActual, CausalActual, ObservacionActual, ObservacionDos, ObservacionTres, Fecha, Hora, latitud, longitud, altura, CicloNuevo, RutaNueva, ConsecutivoNuevo, NumeroFotos, Usuario, impreso, editado,numeroFactura,fechaFactura,fechaLimiteDePago)Values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",[
							i, //Numero
							SepararDato[0],  //IdUsuario
							SepararDato[1],  //Ciclo
							SepararDato[2],  //Ruta
							SepararDato[3],  //Consecutivo
							SepararDato[4],  //Dirección
							SepararDato[5],  //Numero Medidor
							SepararDato[6],  //Tipo Medidor
							SepararDato[7],  //Lectura Anterior
							SepararDato[8],  //Consumo Medio
							SepararDato[9],  //Suscriptor
							SepararDato[10], //Id Uso
							SepararDato[11], //Id Categoria
							SepararDato[12], //Edad Acueducto
							SepararDato[13], //Volumen Aseo
							SepararDato[14], //Cuentas Acueducto Residencial
							SepararDato[15], //Cuentas Acueducto No Residencial
							SepararDato[16], //Cuentas Alcantarillado Residencial
							SepararDato[17], //Cuentas Alcantarillado No Residencial
							SepararDato[18], //Cuentas Aseo Residencial
							SepararDato[19], //Cuentas Aseo No Residencial
							SepararDato[20], //Ultima Fecha de Facturacion
							"",				 //Consumo
							"",				 //ConceptoCrítica
							"", //Lectura Actual
							0, 				 //Causal Actual
							0, 				 //Obs 1
							0, 				 //Obs 2
							0, 				 //Obs 3
							"", //Fecha
							"", //Hora
							"", //Latitud
							"", //Longitud
							"", //Altura
							"", //Ciclo Nuevo
							"", //Ruta Nueva
							"", //Consecutivo Nuevo						
							0,				 //Num Fotos
							"", //Usuario
							"no",			 //Impreso
							"no", //Editado
							"",
							"",
							""]);			 
						
						UsuariosServicios=UsuariosServicios.substring(UltimoDato+1,UsuariosServicios.length); 
						UsuariosServiciosSubidos = i+1;
					}
					swal("Cargue Realizado con éxito", "Cargados " + UsuariosServiciosSubidos + " Usuarios de Servicios", "success");

					confimarUsuariosServicios();
				}
			});
		});
	};
	reader.readAsText(entrada);
}

    // device APIs are available
    //
    function UsuariosServicios() {
        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFSUsuariosServicios, fail);
    }

    function gotFSUsuariosServicios(fileSystem) {
        fileSystem.root.getFile("AQuaMovil/Entradas/UsuariosServicios.csv", null, gotFileEntryUsuariosServicios, fail);
    }

    function gotFileEntryUsuariosServicios(fileEntry) {
        fileEntry.file(gotFileUsuariosServicios, fail);
    }

    function gotFileUsuariosServicios(file){
        cargarUsuariosServicios(file);
    }

    function fail(error) {
        console.log(error.code);
    }

/*----------------------------------------------------------------------------------*/

//Función para borrar UsuariosServicios

function borrarUsuariosServicios()
{
	dbShell.transaction(function(tx)
	{
		tx.executeSql("Drop Table UsuariosServicios");
		CrearTablaUsuariosServicios();
		UsuariosServicios();
	});
}

/*----------------------------------------------------------------------------------*/

//Validación para Reemplazar Lecturas

function confirmarNuevosUsuariosServicios()
{
	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("select Count(*) as Cantidad from UsuariosServicios Where LecturaActual<>'' or CausalActual>0 ",[], 
		function(tx, result)
		{
			if(result.rows.item(0)['Cantidad'] > 0)
			{
				swal({
				title: "Seguro?",   
				text: "Hay registros diligenciados en la base de datos, una vez borrados no podrán recuperarse!",   
				type: "warning",   
				showCancelButton: true,   
				confirmButtonColor: "#FFDC8B",   
				confirmButtonText: "Si, Actualizar",   
				cancelButtonText: "No",   
				closeOnConfirm: false,   
				closeOnCancel: false
				}, 

				function(isConfirm)
				{   
					if (isConfirm)
					{
						borrarUsuariosServicios();
						$("#divCR li").removeClass('pintarCRDiligenciado');
						$("#divCR li").addClass('pintarCRSinDiligenciar');
					} 
					else 
					{
						swal("Cancelado", "Archivo de Usuarios de Servicios Convservado", "error");   
					}
				});
			}
			else
			{
				borrarUsuariosServicios();		
			}	
		});
	});
}

/*----------------------------------------------------------------------------------*/

//Funciones para contar lecturas

function ContarLecturas()
{ 
	var ciclo = document.getElementById("txtCiclo").value;
	var ruta = document.getElementById("txtRuta").value;
	var numero = document.getElementById("txtNumRegistro").value;
   	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("select  Count(*) as Cantidad from UsuariosServicios Where Ciclo=? and Ruta=? ",[ciclo,ruta], 
		function(tx, result)
		{
			var CantidadLecturas=result.rows.item(0)['Cantidad'];
			Adelante(CantidadLecturas,ciclo,ruta,numero);
		});
	});
}

/*----------------------------------------------------------------------------------*/

//Mostrar el registro siguiente

function Adelante(dato,ciclo,ruta,num)
{
	$("#btnAnt").attr("onClick", "validarLectAnt()");
	var numero =  parseInt(num);
	var cantidad = dato;
	var cic = ciclo;
	var rut = ruta;

	if(numero != cantidad-1)
	{
		var RegAnt = numero;	
		var RegSig = numero + 1;
		var RegSigSig = numero + 2;
		document.getElementById('txtNumRegistro').value=RegSig;
	}

   	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("select * from UsuariosServicios where Ciclo=? and Ruta=?",[cic,rut], 
		function(tx, result)
		{
			$("#btnAnt span").removeClass("disable");
			$("#btnAnt i").removeClass("disable");

			if(RegSig == cantidad-1)
			{
				document.getElementById('txtIdUsuarioLecturaSig').value = " ";
				$("#btnSig i").addClass("disable");
				$("#btnSig span").addClass("disable");
				$("#btnSig").attr("onClick", " ");
			}

			if(RegSig > 0 && RegSig <= cantidad-2)
			{
				$("#btnSig i").removeClass("disable");
				$("#btnSig span").removeClass("disable");
	
				var ConsecSig = result.rows.item(RegSigSig)['Consecutivo'];

				document.getElementById('txtIdUsuarioLecturaSig').value = "Siguiente: " + result.rows.item(RegSigSig)['IdUsuario'] + ": " + ciclo + "-" + ruta + "-" + ConsecSig;
			}

			var ConsecAnt = result.rows.item(RegAnt)['Consecutivo'];

			document.getElementById('txtIdUsuarioLecturaAnt').value = "Anterior: " + result.rows.item(RegAnt)['IdUsuario'] + ": " + ciclo + "-" + ruta + "-" + ConsecAnt;

			document.getElementById('txtNumero').value = result.rows.item(RegSig)['Numero'];

			document.getElementById('txtIdUsuarioLectura').value = result.rows.item(RegSig)['IdUsuario'];
			document.getElementById('txtidUsuarioLecturaCtrl').value = result.rows.item(RegSig)['IdUsuario'];

			var Ciclotx = result.rows.item(RegSig)['Ciclo'];	
			document.getElementById('txtCiclo2').value = "Ciclo: " + Ciclotx;

			var Rutatx = result.rows.item(RegSig)['Ruta'];
			document.getElementById('txtRuta2').value = "Ruta: " +  Rutatx;

			document.getElementById('txtCRC').value = result.rows.item(RegSig)['Consecutivo'];
			document.getElementById("txtCicloNuevo").value = result.rows.item(RegSig)['CicloNuevo'];
			document.getElementById("txtRutaNueva").value = result.rows.item(RegSig)['RutaNueva'];
			document.getElementById("txtConsecutivoNuevo").value = result.rows.item(RegSig)['ConsecutivoNuevo'];
			document.getElementById("txtImpreso").value = result.rows.item(RegSig)['impreso'];
			document.getElementById("txtEditado").value = result.rows.item(RegSig)['editado'];
			document.getElementById('txtDireccion').value = result.rows.item(RegSig)['Direccion'];
			document.getElementById('txtMedidor').value = "MED.# " + result.rows.item(RegSig)['NumeroMedidor'];
			document.getElementById('consumo').value = result.rows.item(RegSig)['Consumo'];
			document.getElementById('conceptoCritica').value = result.rows.item(RegSig)['ConceptoCritica'];

			var numeroFotostx = result.rows.item(RegSig)['NumeroFotos'];

			document.getElementById('contadorFotos').value = numeroFotostx;
			
			document.getElementById('txtTipoMedidor').value = result.rows.item(RegSig)['TipoMedidor'];

			var IdUsotx = result.rows.item(RegSig)['IdUso'];

			if(IdUsotx == 1){
				document.getElementById('txtUso').value = "USO: RESIDENCIAL";
			}

			if(IdUsotx == 2){
				document.getElementById('txtUso').value = "USO: COMERCIAL";
			}

			if(IdUsotx == 3){
				document.getElementById('txtUso').value = "USO: INDUSTRIAL";
			}

			if(IdUsotx == 4){
				document.getElementById('txtUso').value = "USO: OFICIAL";
			}

			if(IdUsotx == 5){
				document.getElementById('txtUso').value = "USO: ESPECIAL";
			}

			if(IdUsotx == 6){
				document.getElementById('txtUso').value = "USO: PROVISIONAL";
			}

			document.getElementById('txtCategoria').value = "CATEGORIA: " + result.rows.item(RegSig)['IdCategoria'];

			//var LecturaAnteriortx = document.getElementById('txtLecturaAnterior').value;
			//LecturaAnteriortx.innerHTML = result.rows.item(RegSig)['LecturaAnterior'];

			//var ConsumoMediotx = document.getElementById('txtPromedio').value;
			//ConsumoMediotx.innerHTML = result.rows.item(RegSig)['ConsumoMedio'];

			document.getElementById('txtNombre').value = result.rows.item(RegSig)['Suscriptor'];
			document.getElementById('txtLectura').value = result.rows.item(RegSig)['LecturaActual'];
			document.getElementById('txtCausal').value = result.rows.item(RegSig)['CausalActual'];
			document.getElementById('txtObservacion').value = result.rows.item(RegSig)['ObservacionActual'];
			document.getElementById('txtObservacion2').value = result.rows.item(RegSig)['ObservacionDos'];
			document.getElementById('txtObservacion3').value = result.rows.item(RegSig)['ObservacionTres'];

			if(parseInt(result.rows.item(RegSig)['LecturaActual']) >= 0 || parseInt(result.rows.item(RegSig)['CausalActual']) >= 1)
			{
				activarImpresion();
				permitirEditar();
			}

			else
			{
				desactivarImpresion();
				permitirEditar();
			}
		});
	});
}

/*----------------------------------------------------------------------------------*/

//Mostrar el registro anterior

function validarLectAnt()
{
	var ciclo = document.getElementById("txtCiclo").value;
	var ruta = document.getElementById("txtRuta").value;
	var numero = document.getElementById('txtNumRegistro').value
	Atras(ciclo,ruta,numero);
}

function Atras(ciclo,ruta,num) 
{
	$("#btnSig").attr("onClick", "ContarLecturas()");

	var numero = parseInt(num);
	console.log(numero);

	if(numero != 0)
	{
		var RegAnt = numero - 2;
		var Reg = numero -1;
		document.getElementById('txtNumRegistro').value = Reg;
		var RegSig = numero;
	}
	
   	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("select * from UsuariosServicios where Ciclo=? and Ruta=?",[ciclo,ruta], function(tx, result)
		{

			$("#btnSig i").removeClass("disable");
			$("#btnSig span").removeClass("disable");

			if(Reg == 0)
			{
				document.getElementById('txtIdUsuarioLecturaAnt').value = " ";
				$("#btnAnt span").addClass("disable");
				$("#btnAnt i").addClass("disable");
				$("#btnAnt").attr("onClick", " ");
			}

			if(Reg > 0 && Reg < result.rows.length-1)
			{
				$("#btnSig i").removeClass("disable");
				$("#btnAnt i").removeClass("disable");

				var ConsecAnt = result.rows.item(RegAnt)['Consecutivo'];
				
				document.getElementById('txtIdUsuarioLecturaAnt').value = "Anterior: " + result.rows.item(RegAnt)['IdUsuario'] + ": " + ciclo + "-" + ruta + "-" + ConsecAnt;
			}

			var ConsecSig = result.rows.item(RegSig)['Consecutivo'];
			document.getElementById('txtIdUsuarioLecturaSig').value = "Siguiente: " + result.rows.item(RegSig)['IdUsuario'] + ": " + ciclo + "-" + ruta + "-" + ConsecSig;
			  
			document.getElementById('txtIdUsuarioLectura').value = result.rows.item(Reg)['IdUsuario'];
			document.getElementById('txtidUsuarioLecturaCtrl').value = result.rows.item(Reg)['IdUsuario'];

			var Ciclotx = result.rows.item(Reg)['Ciclo'];	
			document.getElementById('txtCiclo2').value = "Ciclo: " + Ciclotx;

			var Rutatx = result.rows.item(Reg)['Ruta'];
			document.getElementById('txtRuta2').value = "Ruta: " + Rutatx;			
			document.getElementById('txtCRC').value = result.rows.item(Reg)['Consecutivo'];
			document.getElementById("txtCicloNuevo").value = result.rows.item(Reg)['CicloNuevo'];
			document.getElementById("txtRutaNueva").value = result.rows.item(Reg)['RutaNueva'];
			document.getElementById("txtConsecutivoNuevo").value = result.rows.item(Reg)['ConsecutivoNuevo'];
			document.getElementById("txtImpreso").value = result.rows.item(Reg)['impreso'];
			document.getElementById("txtEditado").value = result.rows.item(Reg)['editado'];			
			document.getElementById('txtNumero').value = result.rows.item(Reg)['Numero'];
			document.getElementById('txtDireccion').value = result.rows.item(Reg)['Direccion'];
			document.getElementById('txtMedidor').value = "MED.# " + result.rows.item(Reg)['NumeroMedidor'];
			document.getElementById('consumo').value = result.rows.item(Reg)['Consumo'];
			document.getElementById('conceptoCritica').value = result.rows.item(Reg)['ConceptoCritica'];

			var numeroFotostx = result.rows.item(Reg)['NumeroFotos'];

			document.getElementById('contadorFotos').value = numeroFotostx;
						
			document.getElementById('txtTipoMedidor').value = result.rows.item(Reg)['TipoMedidor'];

			var IdUsotx = result.rows.item(Reg)['IdUso'];

			if(IdUsotx == 1){
				document.getElementById('txtUso').value = "USO: RESIDENCIAL";
			}

			if(IdUsotx == 2){
				document.getElementById('txtUso').value = "USO: COMERCIAL";
			}

			if(IdUsotx == 3){
				document.getElementById('txtUso').value = "USO: INDUSTRIAL";
			}

			if(IdUsotx == 4){
				document.getElementById('txtUso').value = "USO: OFICIAL";
			}

			if(IdUsotx == 5){
				document.getElementById('txtUso').value = "USO: ESPECIAL";
			}

			if(IdUsotx == 6){
				document.getElementById('txtUso').value = "USO: PROVISIONAL";
			}

			document.getElementById('txtCategoria').value = "CATEGORIA: " + result.rows.item(Reg)['IdCategoria'];

			//var LecturaAnteriortx = document.getElementById('txtLecturaAnterior').value;
			//LecturaAnteriortx.innerHTML = result.rows.item(Reg)['LecturaAnterior'];

			//var ConsumoMediotx = document.getElementById('txtPromedio').value;
			//ConsumoMediotx.innerHTML = result.rows.item(Reg)['ConsumoMedio'];

			document.getElementById('txtNombre').value = result.rows.item(Reg)['Suscriptor'];

			document.getElementById('txtLectura').value = result.rows.item(Reg)['LecturaActual'];

			document.getElementById('txtCausal').value = result.rows.item(Reg)['CausalActual'];

			document.getElementById('txtObservacion').value = result.rows.item(Reg)['ObservacionActual'];

			document.getElementById('txtObservacion2').value = result.rows.item(Reg)['ObservacionDos'];

			document.getElementById('txtObservacion3').value = result.rows.item(Reg)['ObservacionTres'];

			if(parseInt(result.rows.item(Reg)['LecturaActual']) >= 0 || parseInt(result.rows.item(Reg)['CausalActual']) >= 1)
			{
				activarImpresion();
				permitirEditar();
			}

			else
			{	
				desactivarImpresion();
				permitirEditar();
			}	  
		});
	});	
}