/*--------------------------------------------------------------------------------*/

//Función para tomar foto desde el menú de cargue

function onPhotoURISuccess(imageURI) 
{
	var gotFileEntry = function(fileEntry) 
	{
		//alert(“got image file entry: ” + fileEntry.fullPath);
		var gotFileSystem = function(fileSystem) 
		{
			fileSystem.root.getDirectory("AQuaMovil/Salidas/Fotos", {create : true, exclusive: false}, function(dataDir) 
			{
				contarFotos();

				var idOperador = document.getElementById("idOperario").value;

				if (idOperador.length < 10)
				{
					idOperador = "0" + idOperador;
				}

				var idUsuario = document.getElementById("txtIdUsuarioLectura").value;

				while(idUsuario.length < 6)
				{
					idUsuario = "0" + idUsuario;
				}

				var periodo = document.getElementById("periodoActual").value;

				while(periodo.length < 3)
				{
					periodo = "0" + periodo;
				}

				var date = new Date();
				var d  = date.getDate();
				var day = (d < 10) ? '0' + d : d;
				var w = date.getMonth() + 1;
				var month = (w < 10) ? '0' + w : w;
				var yy = date.getYear();
				var year = (yy < 1000) ? yy + 1900 : yy;
				var year2 = year.toString();
				var año = year2.substring(2,4);

				var fecha =day+""+month+""+año;

				var consecutivoFoto = (parseInt(document.getElementById("contadorFotos").value) + 1) + "";

				while(consecutivoFoto.length < 3)
				{
					consecutivoFoto = "0" + consecutivoFoto;
				}

				//new file name
				var newFileName = "F" + idOperador + "" + idUsuario + "" + fecha + "" + periodo + "" +consecutivoFoto + ".jpg";

				console.log("Imagen Guardada" + dataDir);

				// copy the file
				fileEntry.moveTo(dataDir, newFileName, null, fsFail);
			}, dirFail);
		};
		// get file system to copy or move image file to
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, fsFail);
	};

	// resolve file system for image
	window.resolveLocalFileSystemURI(imageURI, gotFileEntry, fsFail);
	// file system fail
	var fsFail = function(error) 
	{
		swal("failed with error code: " + error.code);
	};

	var dirFail = function(error) 
	{
		swal("Directory error code: " + error.code);
	};
}

function onFail()
{
	swal("Toma de Foto Cancelada");
}

function Foto() 
{
	// Take picture using device camera and retrieve image as base64-encoded string
	navigator.camera.getPicture(onPhotoURISuccess, onFail, { quality: 50,
	destinationType: Camera.DestinationType.FILE_URI, cameraDirection: Camera.Direction.BACK });
}

function contarFotos()
{
	var numeroReg = document.getElementById('txtNumero').value;
	var fotosReg = parseInt(document.getElementById("contadorFotos").value);

	fotosReg = fotosReg + 1;

	console.log(fotosReg);

	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("Update UsuariosServicios set NumeroFotos=? where Numero=?",[fotosReg,numeroReg],
		function(tx, result)
		{
			document.getElementById("contadorFotos").value = fotosReg;
			console.log(fotosReg);
			swal("Correcto", "Foto Guardada", "success");
		});
	});
}

/*--------------------------------------------------------------------------------*/

//Función para tomar foto de Causal

function onPhotoURISuccessCausal(imageURI) 
{
	var gotFileEntry = function(fileEntry) 
	{
		//alert(“got image file entry: ” + fileEntry.fullPath);
		var gotFileSystem = function(fileSystem) 
		{
			fileSystem.root.getDirectory("AQuaMovil/Salidas/Fotos", {create : true, exclusive: false}, function(dataDir) 
			{
				contarFotosCausal();

				var idOperador = document.getElementById("idOperario").value;

				if (idOperador.length == 1)
				{
					idOperador = "0" + idOperador;
				}

				var idUsuario = document.getElementById("txtIdUsuarioLectura").value;

				while(idUsuario.length < 6)
				{
					idUsuario = "0" + idUsuario;
				}

				var periodo = document.getElementById("periodoActual").value;

				while(periodo.length < 3)
				{
					periodo = "0" + periodo;
				}

				var date = new Date();
				var d  = date.getDate();
				var day = (d < 10) ? '0' + d : d;
				var w = date.getMonth() + 1;
				var month = (w < 10) ? '0' + w : w;
				var yy = date.getYear();
				var year = (yy < 1000) ? yy + 1900 : yy;
				var year2 = year.toString();
				var año = year2.substring(2,4);

				var fecha =day+""+month+""+año;

				var consecutivoFoto = (parseInt(document.getElementById("contadorFotos").value) + 1) + "";

				while(consecutivoFoto.length < 3)
				{
					consecutivoFoto = "0" + consecutivoFoto;
				}

				//new file name
				var newFileName = "F" + idOperador + "" + idUsuario + "" + fecha + "" + periodo + "" +consecutivoFoto + ".jpg";

				console.log("Imagen Guardada" + dataDir);

				// copy the file
				fileEntry.moveTo(dataDir, newFileName, null, fsFail);
			}, dirFail);
		};
		// get file system to copy or move image file to
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, fsFail);
	};

	// resolve file system for image
	window.resolveLocalFileSystemURI(imageURI, gotFileEntry, fsFail);
	// file system fail
	var fsFail = function(error) 
	{
		swal("failed with error code: " + error.code);
	};

	var dirFail = function(error) 
	{
		swal("Directory error code: " + error.code);
	};
}

function FotoCausal() 
{
	// Take picture using device camera and retrieve image as base64-encoded string
	navigator.camera.getPicture(onPhotoURISuccessCausal, onFail, { quality: 50,
	destinationType: Camera.DestinationType.FILE_URI, cameraDirection: Camera.Direction.BACK });
}

function contarFotosCausal()
{
	var numeroReg = document.getElementById('txtNumero').value;
	var fotosReg = parseInt(document.getElementById("contadorFotos").value);

	fotosReg = fotosReg + 1;

	console.log(fotosReg);

	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("Update UsuariosServicios set NumeroFotos=? where Numero=?",[fotosReg,numeroReg],
		function(tx, result)
		{
			document.getElementById("contadorFotos").value = fotosReg;
			console.log(fotosReg);
			swal({
					title: "Correcto",
					text: "Foto Guardada",
					type: "success",
					timer: 2000,
					showConfirmButton: false
				});

			setTimeout("verficarCausal()", 2200);
		});
	});
}

/*--------------------------------------------------------------------------------*/

//Función para tomar foto de la primera observación

function onPhotoURISuccessObservacion1(imageURI) 
{
	var gotFileEntry = function(fileEntry) 
	{
		//alert(“got image file entry: ” + fileEntry.fullPath);
		var gotFileSystem = function(fileSystem) 
		{
			fileSystem.root.getDirectory("AQuaMovil/Salidas/Fotos", {create : true, exclusive: false}, function(dataDir) 
			{
				contarFotosObservacion1();

				var idOperador = document.getElementById("idOperario").value;

				if (idOperador.length == 1)
				{
					idOperador = "0" + idOperador;
				}

				var idUsuario = document.getElementById("txtIdUsuarioLectura").value;

				while(idUsuario.length < 6)
				{
					idUsuario = "0" + idUsuario;
				}

				var periodo = document.getElementById("periodoActual").value;

				while(periodo.length < 3)
				{
					periodo = "0" + periodo;
				}

				var date = new Date();
				var d  = date.getDate();
				var day = (d < 10) ? '0' + d : d;
				var w = date.getMonth() + 1;
				var month = (w < 10) ? '0' + w : w;
				var yy = date.getYear();
				var year = (yy < 1000) ? yy + 1900 : yy;
				var year2 = year.toString();
				var año = year2.substring(2,4);

				var fecha =day+""+month+""+año;

				var consecutivoFoto = (parseInt(document.getElementById("contadorFotos").value) + 1) + "";

				while(consecutivoFoto.length < 3)
				{
					consecutivoFoto = "0" + consecutivoFoto;
				}

				//new file name
				var newFileName = "F" + idOperador + "" + idUsuario + "" + fecha + "" + periodo + "" +consecutivoFoto + ".jpg";

				console.log("Imagen Guardada" + dataDir);

				// copy the file
				fileEntry.moveTo(dataDir, newFileName, null, fsFail);
			}, dirFail);
		};
		// get file system to copy or move image file to
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, fsFail);
	};

	// resolve file system for image
	window.resolveLocalFileSystemURI(imageURI, gotFileEntry, fsFail);
	// file system fail
	var fsFail = function(error) 
	{
		swal("failed with error code: " + error.code);
	};

	var dirFail = function(error) 
	{
		swal("Directory error code: " + error.code);
	};
}

function FotoObservacion1() 
{
	// Take picture using device camera and retrieve image as base64-encoded string
	navigator.camera.getPicture(onPhotoURISuccessObservacion1, onFail, { quality: 50,
	destinationType: Camera.DestinationType.FILE_URI, cameraDirection: Camera.Direction.BACK });
}

function contarFotosObservacion1()
{
	var idObservacion = document.getElementById("txtCodObservacion").value
	document.getElementById("txtObservacion").value = idObservacion;
	var numeroReg = document.getElementById('txtNumero').value;
	var fotosReg = parseInt(document.getElementById("contadorFotos").value);

	fotosReg = fotosReg + 1;

	console.log(fotosReg);

	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("Update UsuariosServicios set NumeroFotos=? where Numero=?",[fotosReg,numeroReg],
		function(tx, result)
		{
			document.getElementById("contadorFotos").value = fotosReg;
			console.log(fotosReg);
			swal({
				title: "Correcto",
				text: "Foto Guardada",
				type: "success",
				timer: 2000,
				showConfirmButton: false
				});

			setTimeout("ActualizarArchivo()", 2200);
		});
	});
}

/*--------------------------------------------------------------------------------*/

//Función para tomar foto de la segunda observación

function onPhotoURISuccessObservacion2(imageURI) 
{
	var gotFileEntry = function(fileEntry) 
	{
		//alert(“got image file entry: ” + fileEntry.fullPath);
		var gotFileSystem = function(fileSystem) 
		{
			fileSystem.root.getDirectory("AQuaMovil/Salidas/Fotos", {create : true, exclusive: false}, function(dataDir) 
			{
				contarFotosObservacion2();

				var idOperador = document.getElementById("idOperario").value;

				if (idOperador.length == 1)
				{
					idOperador = "0" + idOperador;
				}

				var idUsuario = document.getElementById("txtIdUsuarioLectura").value;

				while(idUsuario.length < 6)
				{
					idUsuario = "0" + idUsuario;
				}

				var periodo = document.getElementById("periodoActual").value;

				while(periodo.length < 3)
				{
					periodo = "0" + periodo;
				}

				var date = new Date();
				var d  = date.getDate();
				var day = (d < 10) ? '0' + d : d;
				var w = date.getMonth() + 1;
				var month = (w < 10) ? '0' + w : w;
				var yy = date.getYear();
				var year = (yy < 1000) ? yy + 1900 : yy;
				var year2 = year.toString();
				var año = year2.substring(2,4);

				var fecha =day+""+month+""+año;

				var consecutivoFoto = (parseInt(document.getElementById("contadorFotos").value) + 1) + "";

				while(consecutivoFoto.length < 3)
				{
					consecutivoFoto = "0" + consecutivoFoto;
				}

				//new file name
				var newFileName = "F" + idOperador + "" + idUsuario + "" + fecha + "" + periodo + "" +consecutivoFoto + ".jpg";

				console.log("Imagen Guardada" + dataDir);

				// copy the file
				fileEntry.moveTo(dataDir, newFileName, null, fsFail);
			}, dirFail);
		};
		// get file system to copy or move image file to
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, fsFail);
	};

	// resolve file system for image
	window.resolveLocalFileSystemURI(imageURI, gotFileEntry, fsFail);
	// file system fail
	var fsFail = function(error) 
	{
		swal("failed with error code: " + error.code);
	};

	var dirFail = function(error) 
	{
		swal("Directory error code: " + error.code);
	};
}

function FotoObservacion2() 
{
	// Take picture using device camera and retrieve image as base64-encoded string
	navigator.camera.getPicture(onPhotoURISuccessObservacion2, onFail, { quality: 50,
	destinationType: Camera.DestinationType.FILE_URI, cameraDirection: Camera.Direction.BACK });
}

function contarFotosObservacion2()
{
	var idObservacion = document.getElementById("txtCodObservacion2").value;
	document.getElementById("txtObservacion2").value = idObservacion;
	var numeroReg = document.getElementById('txtNumero').value;
	var fotosReg = parseInt(document.getElementById("contadorFotos").value);

	fotosReg = fotosReg + 1;

	console.log(fotosReg);

	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("Update UsuariosServicios set NumeroFotos=? where Numero=?",[fotosReg,numeroReg],
		function(tx, result)
		{
			document.getElementById("contadorFotos").value = fotosReg;
			console.log(fotosReg);
			swal({
				title: "Correcto",
				text: "Foto Guardada",
				type: "success",
				timer: 2000,
				showConfirmButton: false
				});

			setTimeout("ActualizarArchivo()", 2200);
		});
	});
}

/*--------------------------------------------------------------------------------*/

//Función para tomar foto de la tercera observación

function onPhotoURISuccessObservacion3(imageURI) 
{
	var gotFileEntry = function(fileEntry) 
	{
		//alert(“got image file entry: ” + fileEntry.fullPath);
		var gotFileSystem = function(fileSystem) 
		{
			fileSystem.root.getDirectory("AQuaMovil/Salidas/Fotos", {create : true, exclusive: false}, function(dataDir) 
			{
				contarFotosObservacion3();

				var idOperador = document.getElementById("idOperario").value;

				if (idOperador.length == 1)
				{
					idOperador = "0" + idOperador;
				}

				var idUsuario = document.getElementById("txtIdUsuarioLectura").value;

				while(idUsuario.length < 6)
				{
					idUsuario = "0" + idUsuario;
				}

				var periodo = document.getElementById("periodoActual").value;

				while(periodo.length < 3)
				{
					periodo = "0" + periodo;
				}

				var date = new Date();
				var d  = date.getDate();
				var day = (d < 10) ? '0' + d : d;
				var w = date.getMonth() + 1;
				var month = (w < 10) ? '0' + w : w;
				var yy = date.getYear();
				var year = (yy < 1000) ? yy + 1900 : yy;
				var year2 = year.toString();
				var año = year2.substring(2,4);

				var fecha =day+""+month+""+año;

				var consecutivoFoto = (parseInt(document.getElementById("contadorFotos").value) + 1) + "";

				while(consecutivoFoto.length < 3)
				{
					consecutivoFoto = "0" + consecutivoFoto;
				}

				//new file name
				var newFileName = "F" + idOperador + "" + idUsuario + "" + fecha + "" + periodo + "" +consecutivoFoto + ".jpg";

				console.log("Imagen Guardada" + dataDir);

				// copy the file
				fileEntry.moveTo(dataDir, newFileName, null, fsFail);
			}, dirFail);
		};
		// get file system to copy or move image file to
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, fsFail);
	};

	// resolve file system for image
	window.resolveLocalFileSystemURI(imageURI, gotFileEntry, fsFail);
	// file system fail
	var fsFail = function(error) 
	{
		swal("failed with error code: " + error.code);
	};

	var dirFail = function(error) 
	{
		swal("Directory error code: " + error.code);
	};
}

function FotoObservacion3() 
{
	// Take picture using device camera and retrieve image as base64-encoded string
	navigator.camera.getPicture(onPhotoURISuccessObservacion3, onFail, { quality: 50,
	destinationType: Camera.DestinationType.FILE_URI, cameraDirection: Camera.Direction.BACK });
}

function contarFotosObservacion3()
{
	var idObservacion = document.getElementById("txtCodObservacion3").value;
	document.getElementById("txtObservacion3").value = idObservacion;
	var numeroReg = document.getElementById('txtNumero').value;
	var fotosReg = parseInt(document.getElementById("contadorFotos").value);

	fotosReg = fotosReg + 1;

	console.log(fotosReg);

	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("Update UsuariosServicios set NumeroFotos=? where Numero=?",[fotosReg,numeroReg],
		function(tx, result)
		{
			document.getElementById("contadorFotos").value = fotosReg;
			console.log(fotosReg);
			swal({
				title: "Correcto",
				text: "Foto Guardada",
				type: "success",
				timer: 2000,
				showConfirmButton: false
				});

			setTimeout("ActualizarArchivo()", 2200);
		});

	});
}

/*--------------------------------------------------------------------------------*/

//Función para tomar foto de la primera observación ingresadas desde el menú de cargue

function onPhotoURISuccessObservacion4(imageURI) 
{
	var gotFileEntry = function(fileEntry) 
	{
		//alert(“got image file entry: ” + fileEntry.fullPath);
		var gotFileSystem = function(fileSystem) 
		{
			fileSystem.root.getDirectory("AQuaMovil/Salidas/Fotos", {create : true, exclusive: false}, function(dataDir) 
			{
				contarFotosObservacion4();

				var idOperador = document.getElementById("idOperario").value;

				if (idOperador.length == 1)
				{
					idOperador = "0" + idOperador;
				}

				var idUsuario = document.getElementById("txtIdUsuarioLectura").value;

				while(idUsuario.length < 6)
				{
					idUsuario = "0" + idUsuario;
				}

				var periodo = document.getElementById("periodoActual").value;

				while(periodo.length < 3)
				{
					periodo = "0" + periodo;
				}

				var date = new Date();
				var d  = date.getDate();
				var day = (d < 10) ? '0' + d : d;
				var w = date.getMonth() + 1;
				var month = (w < 10) ? '0' + w : w;
				var yy = date.getYear();
				var year = (yy < 1000) ? yy + 1900 : yy;
				var year2 = year.toString();
				var año = year2.substring(2,4);

				var fecha =day+""+month+""+año;

				var consecutivoFoto = (parseInt(document.getElementById("contadorFotos").value) + 1) + "";

				while(consecutivoFoto.length < 3)
				{
					consecutivoFoto = "0" + consecutivoFoto;
				}

				//new file name
				var newFileName = "F" + idOperador + "" + idUsuario + "" + fecha + "" + periodo + "" +consecutivoFoto + ".jpg";

				console.log("Imagen Guardada" + dataDir);

				// copy the file
				fileEntry.moveTo(dataDir, newFileName, null, fsFail);
			}, dirFail);
		};
		// get file system to copy or move image file to
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, fsFail);
	};

	// resolve file system for image
	window.resolveLocalFileSystemURI(imageURI, gotFileEntry, fsFail);
	// file system fail
	var fsFail = function(error) 
	{
		swal("failed with error code: " + error.code);
	};

	var dirFail = function(error) 
	{
		swal("Directory error code: " + error.code);
	};
}

function FotoObservacion4() 
{
	// Take picture using device camera and retrieve image as base64-encoded string
	navigator.camera.getPicture(onPhotoURISuccessObservacion4, onFail, { quality: 50,
	destinationType: Camera.DestinationType.FILE_URI, cameraDirection: Camera.Direction.BACK });
}

function contarFotosObservacion4()
{
	var idObservacion = document.getElementById("txtCodObservacionCargue").value;
	var numeroReg = document.getElementById('txtNumero').value;
	var fotosReg = parseInt(document.getElementById("contadorFotos").value);

	fotosReg = fotosReg + 1;

	console.log(fotosReg);

	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("Update UsuariosServicios set NumeroFotos=? where Numero=?",[fotosReg,numeroReg],
		function(tx, result)
		{
			document.getElementById("contadorFotos").value = fotosReg;
			console.log(fotosReg);
			swal({
				title: "Correcto",
				text: "Foto Guardada",
				type: "success",
				showCancelButton: false,
				confirmButtonColor: "#0088C4",
				confirmButtonText: "Aceptar",
				closeOnConfirm: true,
				closeOnCancel: false},

				function(isConfirm)
				{
					if (isConfirm) 
					{
						validarNuevaObs1(idObservacion);
				  	}
				});
		});
	});
}

/*--------------------------------------------------------------------------------*/

//Función para tomar foto de la segunda observación ingresadas desde el menú de cargue

function onPhotoURISuccessObservacion5(imageURI) 
{
	var gotFileEntry = function(fileEntry) 
	{
		//alert(“got image file entry: ” + fileEntry.fullPath);
		var gotFileSystem = function(fileSystem) 
		{
			fileSystem.root.getDirectory("AQuaMovil/Salidas/Fotos", {create : true, exclusive: false}, function(dataDir) 
			{
				contarFotosObservacion5();

				var idOperador = document.getElementById("idOperario").value;

				if (idOperador.length == 1)
				{
					idOperador = "0" + idOperador;
				}

				var idUsuario = document.getElementById("txtIdUsuarioLectura").value;

				while(idUsuario.length < 6)
				{
					idUsuario = "0" + idUsuario;
				}

				var periodo = document.getElementById("periodoActual").value;

				while(periodo.length < 3)
				{
					periodo = "0" + periodo;
				}

				var date = new Date();
				var d  = date.getDate();
				var day = (d < 10) ? '0' + d : d;
				var w = date.getMonth() + 1;
				var month = (w < 10) ? '0' + w : w;
				var yy = date.getYear();
				var year = (yy < 1000) ? yy + 1900 : yy;
				var year2 = year.toString();
				var año = year2.substring(2,4);

				var fecha =day+""+month+""+año;

				var consecutivoFoto = (parseInt(document.getElementById("contadorFotos").value) + 1) + "";

				while(consecutivoFoto.length < 3)
				{
					consecutivoFoto = "0" + consecutivoFoto;
				}

				//new file name
				var newFileName = "F" + idOperador + "" + idUsuario + "" + fecha + "" + periodo + "" +consecutivoFoto + ".jpg";

				console.log("Imagen Guardada" + dataDir);

				// copy the file
				fileEntry.moveTo(dataDir, newFileName, null, fsFail);
			}, dirFail);
		};
		// get file system to copy or move image file to
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, fsFail);
	};

	// resolve file system for image
	window.resolveLocalFileSystemURI(imageURI, gotFileEntry, fsFail);
	// file system fail
	var fsFail = function(error) 
	{
		swal("failed with error code: " + error.code);
	};

	var dirFail = function(error) 
	{
		swal("Directory error code: " + error.code);
	};
}

function FotoObservacion5() 
{
	// Take picture using device camera and retrieve image as base64-encoded string
	navigator.camera.getPicture(onPhotoURISuccessObservacion5, onFail, { quality: 50,
	destinationType: Camera.DestinationType.FILE_URI, cameraDirection: Camera.Direction.BACK });
}

function contarFotosObservacion5()
{
	var idObservacion = document.getElementById("txtCodObservacion2Cargue").value;
	var numeroReg = document.getElementById('txtNumero').value;
	var fotosReg = parseInt(document.getElementById("contadorFotos").value);

	fotosReg = fotosReg + 1;

	console.log(fotosReg);

	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("Update UsuariosServicios set NumeroFotos=? where Numero=?",[fotosReg,numeroReg],
		function(tx, result)
		{
			document.getElementById("contadorFotos").value = fotosReg;
			console.log(fotosReg);
			swal({
				title: "Correcto",
				text: "Foto Guardada",
				type: "success",
				showCancelButton: false,
				confirmButtonColor: "#0088C4",
				confirmButtonText: "Aceptar",
				closeOnConfirm: true,
				closeOnCancel: false},

				function(isConfirm)
				{
					if (isConfirm) 
					{
						validarNuevaObs2(idObservacion);
				  	}
				});
		});
	});
}

/*--------------------------------------------------------------------------------*/

//Función para tomar foto de la segunda observación ingresadas desde el menú de cargue

function onPhotoURISuccessObservacion6(imageURI) 
{
	var gotFileEntry = function(fileEntry) 
	{
		//alert(“got image file entry: ” + fileEntry.fullPath);
		var gotFileSystem = function(fileSystem) 
		{
			fileSystem.root.getDirectory("AQuaMovil/Salidas/Fotos", {create : true, exclusive: false}, function(dataDir) 
			{
				contarFotosObservacion6();

				var idOperador = document.getElementById("idOperario").value;

				if (idOperador.length == 1)
				{
					idOperador = "0" + idOperador;
				}

				var idUsuario = document.getElementById("txtIdUsuarioLectura").value;

				while(idUsuario.length < 6)
				{
					idUsuario = "0" + idUsuario;
				}

				var periodo = document.getElementById("periodoActual").value;

				while(periodo.length < 3)
				{
					periodo = "0" + periodo;
				}

				var date = new Date();
				var d  = date.getDate();
				var day = (d < 10) ? '0' + d : d;
				var w = date.getMonth() + 1;
				var month = (w < 10) ? '0' + w : w;
				var yy = date.getYear();
				var year = (yy < 1000) ? yy + 1900 : yy;
				var year2 = year.toString();
				var año = year2.substring(2,4);

				var fecha =day+""+month+""+año;

				var consecutivoFoto = (parseInt(document.getElementById("contadorFotos").value) + 1) + "";

				while(consecutivoFoto.length < 3)
				{
					consecutivoFoto = "0" + consecutivoFoto;
				}

				//new file name
				var newFileName = "F" + idOperador + "" + idUsuario + "" + fecha + "" + periodo + "" +consecutivoFoto + ".jpg";

				console.log("Imagen Guardada" + dataDir);

				// copy the file
				fileEntry.moveTo(dataDir, newFileName, null, fsFail);
			}, dirFail);
		};
		// get file system to copy or move image file to
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, fsFail);
	};

	// resolve file system for image
	window.resolveLocalFileSystemURI(imageURI, gotFileEntry, fsFail);
	// file system fail
	var fsFail = function(error) 
	{
		swal("failed with error code: " + error.code);
	};

	var dirFail = function(error) 
	{
		swal("Directory error code: " + error.code);
	};
}

function FotoObservacion6() 
{
	// Take picture using device camera and retrieve image as base64-encoded string
	navigator.camera.getPicture(onPhotoURISuccessObservacion6, onFail, { quality: 50,
	destinationType: Camera.DestinationType.FILE_URI, cameraDirection: Camera.Direction.BACK });
}

function contarFotosObservacion6()
{
	var idObservacion = document.getElementById("txtCodObservacion3Cargue").value;
	var numeroReg = document.getElementById('txtNumero').value;
	var fotosReg = parseInt(document.getElementById("contadorFotos").value);

	fotosReg = fotosReg + 1;

	console.log(fotosReg);

	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("Update UsuariosServicios set NumeroFotos=? where Numero=?",[fotosReg,numeroReg],
		function(tx, result)
		{
			document.getElementById("contadorFotos").value = fotosReg;
			console.log(fotosReg);
			swal({
				title: "Correcto",
				text: "Foto Guardada",
				type: "success",
				showCancelButton: false,
				confirmButtonColor: "#0088C4",
				confirmButtonText: "Aceptar",
				closeOnConfirm: true,
				closeOnCancel: false},

				function(isConfirm)
				{
					if (isConfirm) 
					{
						validarNuevaObs3(idObservacion);
				  	}
				});
		});
	});
}