/*----------------------------------------------------------------------------------*/

//Función para cargar Acumulados Anteriores

function cargarAcumuladosAnteriores(entrada)
{	
	var reader = new FileReader();
	
	reader.onloadend=function(evento)
	{
		var AcumuladosAnteriores = evento.target.result;			
		dbShell.transaction(function(tx) 
		{   
			tx.executeSql("select Count(*) as Cantidad  from Usuarios  ",[], 
			function(tx, result)
			{				
				var tipoArchivo= typeof result.rows.item(0)['Cantidad'];
				if(1 == 1)
				{
					var Control = AcumuladosAnteriores.match(/\n/g);
					for(var i = 0; i < Control.length ; i++)
					{						
						var UltimoDato = AcumuladosAnteriores.indexOf('\n'); // Se determina que "/n" es salto de linea
						var Dato = AcumuladosAnteriores.substring(0,UltimoDato);
						var SepararDato = Dato.split(','); // Se determina que cada dato a incluir en la BD se separa con ","
						
						tx.executeSql("Insert Into AcumuladosAnteriores (Numero, IdCargo, IdUsuario, ValorAnterior, Control)Values(?,?,?,?,?)",[
							i, //Numero
							SepararDato[0],  //IdCargo
							SepararDato[1],  //IdUsuario
							SepararDato[2],  //ValorAnterior
							0]); //Control
						
						AcumuladosAnteriores=AcumuladosAnteriores.substring(UltimoDato+1,AcumuladosAnteriores.length); 
						AcumuladosAnterioresSubidos = i+1;
					}
					swal("Cargue Realizado con éxito", "Cargados " + AcumuladosAnterioresSubidos + " Acumulados Anteriores", "success");

					confimarAcumuladosAnteriores();
				}
			});
		});
	};
	reader.readAsText(entrada);
}

    // device APIs are available
    //
    function AcumuladosAnteriores() {
        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFSAcumuladosAnteriores, fail);
    }

    function gotFSAcumuladosAnteriores(fileSystem) {
        fileSystem.root.getFile("AQuaMovil/Entradas/AcumuladosAnteriores.csv", null, gotFileEntryAcumuladosAnteriores, fail);
    }

    function gotFileEntryAcumuladosAnteriores(fileEntry) {
        fileEntry.file(gotFileAcumuladosAnteriores, fail);
    }

    function gotFileAcumuladosAnteriores(file){
        cargarAcumuladosAnteriores(file);
    }

    function fail(error) {
        console.log(error.code);
    }

/*----------------------------------------------------------------------------------*/

//Función para borrar AcumuladosAnteriores

function borrarAcumuladosAnteriores()
{
	dbShell.transaction(function(tx)
	{
		tx.executeSql("Drop Table AcumuladosAnteriores");
		CrearTablaAcumuladosAnteriores();
		AcumuladosAnteriores();
	});
}

/*----------------------------------------------------------------------------------*/

//Función para cargar Cargos de Facturación

function cargarCargosFacturacion(entrada)
{	
	var reader = new FileReader();
	
	reader.onloadend=function(evento)
	{
		var CargosFacturacion = evento.target.result;			
		dbShell.transaction(function(tx) 
		{   
			tx.executeSql("select Count(*) as Cantidad  from Usuarios  ",[], 
			function(tx, result)
			{				
				var tipoArchivo= typeof result.rows.item(0)['Cantidad'];
				if(1 == 1)
				{
					var Control = CargosFacturacion.match(/\n/g);
					for(var i = 0; i < Control.length ; i++)
					{						
						var UltimoDato = CargosFacturacion.indexOf('\n'); // Se determina que "/n" es salto de linea
						var Dato = CargosFacturacion.substring(0,UltimoDato);
						var SepararDato = Dato.split(','); // Se determina que cada dato a incluir en la BD se separa con ","
						
						tx.executeSql("Insert Into CargosFacturacion (Numero, IdCargo, IdServicio, NombreCargo, Tarifa, Control)Values(?,?,?,?,?,?)",[
							i,				 //Numero
							SepararDato[0],  //IdCargo
							SepararDato[1],  //IdSevicio
							SepararDato[2],  //NombreCargo
							SepararDato[3],  //Tarifa
							""]); //Control
						
						CargosFacturacion=CargosFacturacion.substring(UltimoDato+1,CargosFacturacion.length); 
						CargosFacturacionSubidos = i+1;
					}
					swal("Cargue Realizado con éxito", "Cargados " + CargosFacturacionSubidos + " Cargos de Facturación", "success");

					confimarCargosFacturacion();
				}
			});
		});
	};
	reader.readAsText(entrada);
}

    // device APIs are available
    //
    function CargosFacturacion() {
        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFSCargosFacturacion, fail);
    }

    function gotFSCargosFacturacion(fileSystem) {
        fileSystem.root.getFile("AQuaMovil/Entradas/CargosFacturacion.csv", null, gotFileEntryCargosFacturacion, fail);
    }

    function gotFileEntryCargosFacturacion(fileEntry) {
        fileEntry.file(gotFileCargosFacturacion, fail);
    }

    function gotFileCargosFacturacion(file){
        cargarCargosFacturacion(file);
    }

    function fail(error) {
        console.log(error.code);
    }

/*----------------------------------------------------------------------------------*/

//Función para borrar CargosFacturacion

function borrarCargosFacturacion()
{
	dbShell.transaction(function(tx)
	{
		tx.executeSql("Drop Table CargosFacturacion");
		CrearTablaCargosFacturacion();
		CargosFacturacion();
	});
}

/*----------------------------------------------------------------------------------*/

//Función para cargar Indices Subsidios Aportes

function cargarIndicesSubsidiosAportes(entrada)
{	
	var reader = new FileReader();
	
	reader.onloadend=function(evento)
	{
		var IndicesSubsidiosAportes = evento.target.result;			
		dbShell.transaction(function(tx) 
		{   
			tx.executeSql("select Count(*) as Cantidad  from Usuarios  ",[], 
			function(tx, result)
			{				
				var tipoArchivo= typeof result.rows.item(0)['Cantidad'];
				if(1 == 1)
				{
					var Control = IndicesSubsidiosAportes.match(/\n/g);
					for(var i = 0; i < Control.length ; i++)
					{						
						var UltimoDato = IndicesSubsidiosAportes.indexOf('\n'); // Se determina que "/n" es salto de linea
						var Dato = IndicesSubsidiosAportes.substring(0,UltimoDato);
						var SepararDato = Dato.split(','); // Se determina que cada dato a incluir en la BD se separa con ","
						
						tx.executeSql("Insert Into IndicesSubsidiosAportes (Numero, IdCargo, IdUso, IdCategoria, Indice, Control)Values(?,?,?,?,?,?)",[
							i,				 //Numero
							SepararDato[0],  //IdCargo
							SepararDato[1],  //IdSevicio
							SepararDato[2],  //NombreCargo
							SepararDato[3],  //Tarifa
							0]); //Control

						console.log(i);
						console.log(SepararDato[0]);
						console.log(SepararDato[1]);
						console.log(SepararDato[2]);
						console.log(SepararDato[3]);
						
						IndicesSubsidiosAportes=IndicesSubsidiosAportes.substring(UltimoDato+1,IndicesSubsidiosAportes.length); 
						IndicesSubsidiosAportesSubidos = i+1;
					}
					swal("Cargue Realizado con éxito", "Cargados " + IndicesSubsidiosAportesSubidos + " indices Subsidios Aportes", "success");

					confimarIndicesSubsidiosAportes();
				}
			});
		});
	};
	reader.readAsText(entrada);
}

    // device APIs are available
    //
    function IndicesSubsidiosAportes() {
        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFSIndicesSubsidiosAportes, fail);
    }

    function gotFSIndicesSubsidiosAportes(fileSystem) {
        fileSystem.root.getFile("AQuaMovil/Entradas/IndicesSubsidiosAportes.csv", null, gotFileEntryIndicesSubsidiosAportes, fail);
    }

    function gotFileEntryIndicesSubsidiosAportes(fileEntry) {
        fileEntry.file(gotFileIndicesSubsidiosAportes, fail);
    }

    function gotFileIndicesSubsidiosAportes(file){
        cargarIndicesSubsidiosAportes(file);
    }

    function fail(error) {
        console.log(error.code);
    }

/*----------------------------------------------------------------------------------*/

//Función para borrar IndicesSubsidiosAportes

function borrarIndicesSubsidiosAportes()
{
	dbShell.transaction(function(tx)
	{
		tx.executeSql("Drop Table IndicesSubsidiosAportes");
		CrearTablaIndicesSubsidiosAportes();
		IndicesSubsidiosAportes();
	});
}

/*----------------------------------------------------------------------------------*/

//Función para cargar Periodos de Facturación

function cargarPeriodos(entrada)
{	
	var reader = new FileReader();
	
	reader.onloadend=function(evento)
	{
		var Periodos = evento.target.result;			
		dbShell.transaction(function(tx) 
		{   
			tx.executeSql("select Count(*) as Cantidad  from Usuarios  ",[], 
			function(tx, result)
			{				
				var tipoArchivo= typeof result.rows.item(0)['Cantidad'];
				if(1 == 1)
				{
					var Control = Periodos.match(/\n/g);
					for(var i = 0; i < Control.length ; i++)
					{						
						var UltimoDato = Periodos.indexOf('\n'); // Se determina que "/n" es salto de linea
						var Dato = Periodos.substring(0,UltimoDato);
						var SepararDato = Dato.split(','); // Se determina que cada dato a incluir en la BD se separa con ","
						
						tx.executeSql("Insert Into Periodos (Numero, IdPeriodo, NombrePeriodo, FechaInicial, FechaFinal, FechaLimite, Control)Values(?,?,?,?,?,?,?)",[
							i,				 //Numero
							SepararDato[0],  //IdPeriodo
							SepararDato[1],  //NombrePeriodo
							SepararDato[2],  //FechaInicial
							SepararDato[3],  //FechaFinal
							SepararDato[4],  //FechaLimite
							0]); //Control

						console.log(i);
						console.log(SepararDato[0]);
						console.log(SepararDato[1]);
						console.log(SepararDato[2]);
						console.log(SepararDato[3]);
						
						Periodos=Periodos.substring(UltimoDato+1,Periodos.length); 
						PeriodosSubidos = i+1;
					}
					swal("Cargue Realizado con éxito", "Cargado " + PeriodosSubidos + " Periodo", "success");

					confimarPeriodos();
					mostrarPeriodos();
				}
			});
		});
	};
	reader.readAsText(entrada);
}

    // device APIs are available
    //
    function Periodos() {
        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFSPeriodos, fail);
    }

    function gotFSPeriodos(fileSystem) {
        fileSystem.root.getFile("AQuaMovil/Entradas/Periodos.csv", null, gotFileEntryPeriodos, fail);
    }

    function gotFileEntryPeriodos(fileEntry) {
        fileEntry.file(gotFilePeriodos, fail);
    }

    function gotFilePeriodos(file){
        cargarPeriodos(file);
    }

    function fail(error) {
        console.log(error.code);
    }

/*----------------------------------------------------------------------------------*/

//Función para borrar Periodos

function borrarPeriodos()
{
	dbShell.transaction(function(tx)
	{
		tx.executeSql("Drop Table Periodos");
		CrearTablaPeriodos();
		Periodos();
	});
}

function mostrarPeriodos()
{
	dbShell.transaction(function(tx) 
	{   
		tx.executeSql("select * from Periodos ",[], 
		function(tx, result)
		{
			document.getElementById("periodoActual").value = result.rows.item(0)['IdPeriodo'];
		});
	});
}

/*----------------------------------------------------------------------------------*/

//RETORNO A LA PAGINA CICLO-RUTA FACTURACIÓN

function regresarFact()
{
	window.location.href = "#/Ciclorutafacturacion";

	var cicloColor = document.getElementById("txtCiclo").value;
	var rutaColor = document.getElementById("txtRuta").value;
	var id = "CicloFact"+cicloColor+"rutaFact"+rutaColor;

	dbShell.transaction(function(tx) 
	{            
		tx.executeSql("SELECT * FROM UsuariosServicios where Ciclo=? and Ruta=?", [cicloColor,rutaColor],                
		function(tx, result)
		{
			var contador = 0;         
			for(var i = 0; i < result.rows.length; i++) 
			{   
				var a1 = result.rows.item(i)['LecturaActual'];
				var a2 = result.rows.item(i)['CausalActual'];
				var a3 = result.rows.item(i)['ObservacionActual'];

				if(a1 != '' || a2 != '')
				{
					contador++;
				}

				if(contador == result.rows.length)
				{
					$("#"+id).removeClass('pintarCRSinDiligenciar');
					$("#"+id).addClass('pintarCRDiligenciado');
				}
			}

			if(cicloColor != '' && rutaColor != '')
			{
				$("#divCRFact a").removeClass('pintarLR');
				$("#"+id).addClass('pintarLR');
			}
		});    
	});
}

/*----------------------------------------------------------------------------------*/

//Funciones para contar lecturas

function ContarLecturasFact()
{ 
	var ciclo = document.getElementById("txtCiclo").value;
	var ruta = document.getElementById("txtRuta").value;
	var numero = document.getElementById("txtNumRegistro").value;
   	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("select  Count(*) as Cantidad from UsuariosServicios Where Ciclo=? and Ruta=? ",[ciclo,ruta], 
		function(tx, result)
		{
			var CantidadLecturas=result.rows.item(0)['Cantidad'];
			AdelanteFact(CantidadLecturas,ciclo,ruta,numero);
		});
	});
}

/*----------------------------------------------------------------------------------*/

//Mostrar el registro siguiente

function AdelanteFact(dato,ciclo,ruta,num)
{
	$("#btnAntFact").attr("onClick", "validarLectAntFact()");
	var numero =  parseInt(num);
	var cantidad = dato;
	var cic = ciclo;
	var rut = ruta;

	if(numero != cantidad-1)
	{
		var RegAnt = numero;	
		var RegSig = numero + 1;
		var RegSigSig = numero + 2;
		document.getElementById('txtNumRegistro').value=RegSig;
	}

   	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("select * from UsuariosServicios where Ciclo=? and Ruta=?",[cic,rut], 
		function(tx, result)
		{
			$("#btnAntFact span").removeClass("disable");
			$("#btnAntFact i").removeClass("disable");

			if(RegSig == cantidad-1)
			{
				document.getElementById('txtIdUsuarioLecturaSigFact').value = " ";
				$("#btnSigFact i").addClass("disable");
				$("#btnSigFact span").addClass("disable");
				$("#btnSigFact").attr("onClick", " ");
			}

			if(RegSig > 0 && RegSig <= cantidad-2)
			{
				$("#btnSigFact i").removeClass("disable");
				$("#btnSigFact span").removeClass("disable");
	
				var ConsecSig = result.rows.item(RegSigSig)['Consecutivo'];

				document.getElementById('txtIdUsuarioLecturaSigFact').value = "Sig.: " + result.rows.item(RegSigSig)['IdUsuario'] + "-" + ciclo + "-" + ruta + "-" + ConsecSig;
			}

			var ConsecAnt = result.rows.item(RegAnt)['Consecutivo'];

			document.getElementById('txtIdUsuarioLecturaAntFact').value = "Ant.: " + result.rows.item(RegAnt)['IdUsuario'] + "-" + ciclo + "-" + ruta + "-" + ConsecAnt;


			var lecturaActual = result.rows.item(RegSig)['LecturaActual'];
			var causalActual = result.rows.item(RegSig)['CausalActual'];
			var impreso = result.rows.item(RegSig)['impreso'];

			var idUsuario = result.rows.item(RegSig)['IdUsuario'];
			document.getElementById('txtIdUsuarioLecturaFact').value = idUsuario;

			if(impreso == "si")
			{
				console.log('if1');
				activarImpresionFact();
				$("#datos-entrada").show();
				$("#datosGenerales").show();
				$("#LecturaNoDiligenciada").hide();
				document.getElementById('txtNumeroFact').value = result.rows.item(RegSig)['Numero'];
				
				document.getElementById('txtidUsuarioLecturaCtrl').value = idUsuario;

				var Ciclotx = result.rows.item(RegSig)['Ciclo'];
				document.getElementById('txtCiclo2Fact').value = "Ciclo: " + Ciclotx;

				var Rutatx = result.rows.item(RegSig)['Ruta'];
				document.getElementById('txtRuta2Fact').value = "Ruta: " + Rutatx;
				
				document.getElementById("txtImpresoFact").value = impreso;


				var nombreUsuario = result.rows.item(RegSig)['Suscriptor'];
				document.getElementById("txtIdNombreUsuarioFact").innerHTML = "ID:" + "<b>" + idUsuario + " - " + nombreUsuario.toUpperCase() + "</b>";
				
				var direccionUsuario = result.rows.item(RegSig)['Direccion'];
				document.getElementById('txtDireccionFact').innerHTML = "Dirección: <b>" + direccionUsuario.toUpperCase() + "</b>";

				document.getElementById('txtMedidorFact').innerHTML = "MED.# <b>" + result.rows.item(RegSig)['NumeroMedidor'] + "</b>";

				document.getElementById('txtConsumoFact').innerHTML = "Consumo: <b>" + result.rows.item(RegSig)['Consumo'] + "</b>";


				var Uso;
				var IdUsotx = result.rows.item(RegSig)['IdUso'];

				if(IdUsotx == 1)
				{
					Uso = "Uso: <b>RESIDENCIAL</b>";
				}

				if(IdUsotx == 2)
				{
					Uso = "Uso: <b>COMERCIAL</b>";
				}

				if(IdUsotx == 3)
				{
					Uso = "Uso: <b>INDUSTRIAL</b>";
				}

				if(IdUsotx == 4)
				{
					Uso = "Uso: <b>OFICIAL</b>";
				}

				if(IdUsotx == 5)
				{
					Uso = "Uso: <b>ESPECIAL</b>";
				}

				if(IdUsotx == 6)
				{
					Uso = "Uso: <b>PROVISIONAL</b>";
				}

				var categoria = result.rows.item(RegSig)['IdCategoria'];

				document.getElementById("txtUsoCatFact").innerHTML = Uso + " Cat: <b>" + categoria + "</b>";

				var CtasAcR = parseInt(result.rows.item(RegSig)['CtasAcR']);
				var CtasAcNR = parseInt(result.rows.item(RegSig)['CtasAcNR']);
				var CtasAlR = parseInt(result.rows.item(RegSig)['CtasAlR']);
				var CtasAlNR = parseInt(result.rows.item(RegSig)['CtasAlNR']);
				var CtasAsR = parseInt(result.rows.item(RegSig)['CtasAsR']);
				var CtasAsNR = parseInt(result.rows.item(RegSig)['CtasAsNR']);

				var CuentasAcueducto;
				var CuentasAlcantarillado;
				var CuentasAseo;
				var NumeroCuentasAcueducto = CtasAcR+CtasAcNR;
				var NumeroCuentasAlcantarillado = CtasAlR+CtasAlNR;
				var NumeroCuentasAseo = CtasAsR+CtasAsNR;

				if (CtasAcR > 0) 
				{
					CuentasAcueducto = "# Ctas Acued.: <b>" + CtasAcR + " (R)</b>";
				}

				if (CtasAcNR > 0) 
				{
					CuentasAcueducto = "# Ctas Acued.: <b>" + CtasAcR + " (NR)</b>";
				}

				if (CtasAlR > 0) 
				{
					CuentasAlcantarillado = "# Ctas Alcant.: <b>" + CtasAlR + " (R)</b>";
				}

				if (CtasAlNR > 0) 
				{
					CuentasAlcantarillado = "# Ctas Alcant.: <b>" + CtasAlNR + " (NR)</b>";
				}

				if (CtasAsR > 0) 
				{
					CuentasAseo = "# Ctas Aseo: <b>" + CtasAsR + " (R)</b>";
				}

				if (CtasAsNR > 0) 
				{
					CuentasAseo = "# Ctas Aseo: <b>" + CtasAsNR + " (NR)</b>";
				}

				document.getElementById("txtNumCuentasAcueductoFact").innerHTML = CuentasAcueducto;
				document.getElementById("txtNumCuentasAlcantarilladoFact").innerHTML = CuentasAlcantarillado;
				document.getElementById("txtNumCuentasAseoFact").innerHTML = CuentasAseo;

				var VolumenAseo = result.rows.item(RegSig)['VolumenAseo'];

				document.getElementById("txtToneladasProducidasFact").innerHTML = "Ton. de Basura Prod: <b>" + VolumenAseo + "</b>";

				var LecturaAnteriortx = document.getElementById('txtLecturaAnteriorFact');

				LecturaAnteriortx.innerHTML = "Lectura Anterior: <b>" + result.rows.item(RegSig)['LecturaAnterior'] + "</b>";

				var ConsumoMediotx = document.getElementById('txtConsumoPromedioFact');

				ConsumoMediotx.innerHTML = "Consumo Promedio: <b>" + result.rows.item(RegSig)['ConsumoMedio'] + "</b>";

				if (causalActual == 0)
				{
					document.getElementById('txtCausalFact').innerHTML = "";
					document.getElementById('txtLecturaActualFact').innerHTML = "Lectura Actual: <b>" + lecturaActual + "</b>";
				}

				if(causalActual > 0)
				{
					asignarCausalFact(causalActual);	
				}

				var observacionActual = result.rows.item(RegSig)['ObservacionActual'];

				if(observacionActual == 0)
				{
					document.getElementById('txtObservacionFact').innerHTML = "";
				}

				if(observacionActual > 0)
				{
					asignarObsFact(observacionActual);
				}

				var fechaFactura = result.rows.item(RegSig)['fechaFactura'];
				var fechaLimiteDePago = result.rows.item(RegSig)['fechaLimiteDePago'];
				var numeroFactura = result.rows.item(RegSig)['numeroFactura'];

				alert(numeroFactura);

				if (fechaFactura == "") 
				{
					setFechaFactura();
					setNumeroFactura();
				}

				else
				{
					document.getElementById('txtFechaFact').innerHTML = "Fecha Facturación: <b>" + fechaFactura + "</b>";
					document.getElementById('txtFechaFactura').value = fechaFactura;

					document.getElementById('txtFechaLimiteFact').innerHTML = "Fecha Limite de Pago: <b>" + fechaLimiteDePago + "</b>";
					document.getElementById('txtFechaLimiteDePagoFactura').value = fechaLimiteDePago;

					document.getElementById('txtNumeroFactReal').value = numeroFactura;
					document.getElementById('txtNumFact').innerHTML = "Factura #: <b>" + numeroFactura + "</b>";
				}

				cargarDatosEmpresaFact();
				cargarDatosPeriodoFact();

				var ConsuMedio = result.rows.item(RegSig)['ConsumoMedio'];
				var ConsumoMes = result.rows.item(RegSig)['Consumo'];
				var EdadAcueducto = result.rows.item(RegSig)['EdadAcueducto'];
				document.getElementById('txtEdadAcueducto').value = EdadAcueducto;

				if (ConsumoMes > 0) 
				{
					liquidacionFactura(ConsumoMes,VolumenAseo,IdUsotx,categoria,idUsuario,NumeroCuentasAcueducto,NumeroCuentasAlcantarillado,NumeroCuentasAseo,EdadAcueducto);
				}

				else
				{
					liquidacionFactura(ConsuMedio,VolumenAseo,IdUsotx,categoria,idUsuario,NumeroCuentasAcueducto,NumeroCuentasAlcantarillado,NumeroCuentasAseo,EdadAcueducto);
				}

				var fechaLectura = result.rows.item(RegSig)['Fecha'];
				document.getElementById('txtFechaFinalFact').innerHTML = "Fecha de Lectura: <b>" + fechaLectura + "</b>";

				var fechaInicial = result.rows.item(RegSig)['UltimaFechaDeFacturacion'];

				document.getElementById('txtFechaInicialFact').innerHTML = "Fecha Inicial: <b>" + fechaInicial + "</b>";
			}

			else
			{
				console.log('if2');
				desactivarImpresionFact();
				$("#datos-entrada").hide();
				$("#datosGenerales").hide();
				$("#LecturaNoDiligenciada").show();
			}
		});
	});
}

/*----------------------------------------------------------------------------------*/

//Mostrar el registro anterior

function validarLectAntFact()
{
	console.log('validarLectAnt');
	var ciclo = document.getElementById("txtCiclo").value;
	var ruta = document.getElementById("txtRuta").value;
	var numero = document.getElementById('txtNumRegistro').value;
	AtrasFact(ciclo,ruta,numero);
}

function AtrasFact(ciclo,ruta,num) 
{
	$("#btnSigFact").attr("onClick", "ContarLecturasFact()");

	var numero = parseInt(num);
	console.log(numero);

	if(numero != 0)
	{
		var RegAnt = numero - 2;
		var Reg = numero -1;
		document.getElementById('txtNumRegistro').value = Reg;
		var RegSig = numero;
	}

   	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("select * from UsuariosServicios where Ciclo=? and Ruta=?",[ciclo,ruta], function(tx, result)
		{
			$("#btnSigFact i").removeClass("disable");
			$("#btnSigFact span").removeClass("disable");

			if(Reg == 0)
			{
				document.getElementById('txtIdUsuarioLecturaAntFact').value = " ";
				$("#btnAntFact span").addClass("disable");
				$("#btnAntFact i").addClass("disable");
				$("#btnAntFact").attr("onClick", " ");
				console.log('AtrasFact' + ciclo + ruta + num);
			}

			if(Reg > 0 && Reg < result.rows.length-1)
			{
				$("#btnSigFact i").removeClass("disable");
				$("#btnAntFact i").removeClass("disable");

				var ConsecAnt = result.rows.item(RegAnt)['Consecutivo'];
				
				document.getElementById('txtIdUsuarioLecturaAntFact').value = "Ant.: " + result.rows.item(RegAnt)['IdUsuario'] + ": " + ciclo + "-" + ruta + "-" + ConsecAnt;
			}

			var ConsecSig = result.rows.item(RegSig)['Consecutivo'];
			document.getElementById('txtIdUsuarioLecturaSigFact').value = "Sig.: " + result.rows.item(RegSig)['IdUsuario'] + ": " + ciclo + "-" + ruta + "-" + ConsecSig;
			  
			var lecturaActual = result.rows.item(Reg)['LecturaActual'];
			var causalActual = result.rows.item(Reg)['CausalActual'];
			var impreso = result.rows.item(Reg)['impreso'];
			var idUsuario = result.rows.item(Reg)['IdUsuario'];
			document.getElementById('txtIdUsuarioLecturaFact').value = idUsuario;

			if(impreso == "si")
			{
				console.log('if1');
				activarImpresionFact();
				$("#datos-entrada").show();
				$("#datosGenerales").show();
				$("#LecturaNoDiligenciada").hide();
				document.getElementById('txtNumeroFact').value = result.rows.item(Reg)['Numero'];
			
				document.getElementById('txtidUsuarioLecturaCtrl').value = idUsuario;

				var Ciclotx = result.rows.item(Reg)['Ciclo'];
				document.getElementById('txtCiclo2Fact').value = "Ciclo: " + Ciclotx;

				var Rutatx = result.rows.item(Reg)['Ruta'];
				document.getElementById('txtRuta2Fact').value = "Ruta: " + Rutatx;
				
				document.getElementById("txtImpresoFact").value = impreso;


				var nombreUsuario = result.rows.item(Reg)['Suscriptor'];
				document.getElementById("txtIdNombreUsuarioFact").innerHTML = "ID:" + "<b>" + idUsuario + " - " + nombreUsuario.toUpperCase() + "</b>";
				
				var direccionUsuario = result.rows.item(Reg)['Direccion'];
				document.getElementById('txtDireccionFact').innerHTML = "Dirección: <b>" + direccionUsuario.toUpperCase() + "</b>";

				document.getElementById('txtMedidorFact').innerHTML = "MED.# <b>" + result.rows.item(Reg)['NumeroMedidor'] + "</b>";

				document.getElementById('txtConsumoFact').innerHTML = "Consumo: <b>" + result.rows.item(Reg)['Consumo'] + "</b>";


				var Uso;
				var IdUsotx = result.rows.item(Reg)['IdUso'];

				if(IdUsotx == 1)
				{
					Uso = "Uso: <b>RESIDENCIAL</b>";
				}

				if(IdUsotx == 2)
				{
					Uso = "Uso: <b>COMERCIAL</b>";
				}

				if(IdUsotx == 3)
				{
					Uso = "Uso: <b>INDUSTRIAL</b>";
				}

				if(IdUsotx == 4)
				{
					Uso = "Uso: <b>OFICIAL</b>";
				}

				if(IdUsotx == 5)
				{
					Uso = "Uso: <b>ESPECIAL</b>";
				}

				if(IdUsotx == 6)
				{
					Uso = "Uso: <b>PROVISIONAL</b>";
				}

				var categoria = result.rows.item(Reg)['IdCategoria'];

				document.getElementById("txtUsoCatFact").innerHTML = Uso + " Cat: <b>" + categoria + "</b>";

				var CtasAcR = parseInt(result.rows.item(Reg)['CtasAcR']);
				var CtasAcNR = parseInt(result.rows.item(Reg)['CtasAcNR']);
				var CtasAlR = parseInt(result.rows.item(Reg)['CtasAlR']);
				var CtasAlNR = parseInt(result.rows.item(Reg)['CtasAlNR']);
				var CtasAsR = parseInt(result.rows.item(Reg)['CtasAsR']);
				var CtasAsNR = parseInt(result.rows.item(Reg)['CtasAsNR']);

				var CuentasAcueducto;
				var CuentasAlcantarillado;
				var CuentasAseo;
				var NumeroCuentasAcueducto = CtasAcR+CtasAcNR;
				var NumeroCuentasAlcantarillado = CtasAlR+CtasAlNR;
				var NumeroCuentasAseo = CtasAsR+CtasAsNR;

				if (CtasAcR > 0) 
				{
					CuentasAcueducto = "# Ctas Acued.: <b>" + CtasAcR + " (R)</b>";
				}

				if (CtasAcNR > 0) 
				{
					CuentasAcueducto = "# Ctas Acued.: <b>" + CtasAcR + " (NR)</b>";
				}

				if (CtasAlR > 0) 
				{
					CuentasAlcantarillado = "# Ctas Alcant.: <b>" + CtasAlR + " (R)</b>";
				}

				if (CtasAlNR > 0) 
				{
					CuentasAlcantarillado = "# Ctas Alcant.: <b>" + CtasAlNR + " (NR)</b>";
				}

				if (CtasAsR > 0) 
				{
					CuentasAseo = "# Ctas Aseo: <b>" + CtasAsR + " (R)</b>";
				}

				if (CtasAsNR > 0) 
				{
					CuentasAseo = "# Ctas Aseo: <b>" + CtasAsNR + " (NR)</b>";
				}

				document.getElementById("txtNumCuentasAcueductoFact").innerHTML = CuentasAcueducto;
				document.getElementById("txtNumCuentasAlcantarilladoFact").innerHTML = CuentasAlcantarillado;
				document.getElementById("txtNumCuentasAseoFact").innerHTML = CuentasAseo;

				var VolumenAseo = result.rows.item(Reg)['VolumenAseo'];

				document.getElementById("txtToneladasProducidasFact").innerHTML = "Ton. de Basura Prod: <b>" + VolumenAseo + "</b>";

				var LecturaAnteriortx = document.getElementById('txtLecturaAnteriorFact');

				LecturaAnteriortx.innerHTML = "Lectura Anterior: <b>" + result.rows.item(Reg)['LecturaAnterior'] + "</b>";

				var ConsumoMediotx = document.getElementById('txtConsumoPromedioFact');

				ConsumoMediotx.innerHTML = "Consumo Promedio: <b>" + result.rows.item(Reg)['ConsumoMedio'] + "</b>";

				if (causalActual == 0)
				{
					document.getElementById('txtCausalFact').innerHTML = "";
					document.getElementById('txtLecturaActualFact').innerHTML = "Lectura Actual: <b>" + lecturaActual + "</b>";
				}

				if(causalActual > 0)
				{
					asignarCausalFact(causalActual);	
				}

				var observacionActual = result.rows.item(Reg)['ObservacionActual'];

				if(observacionActual == 0)
				{
					document.getElementById('txtObservacionFact').innerHTML = "";
				}

				if(observacionActual > 0)
				{
					asignarObsFact(observacionActual);
				}

				var fechaFactura = result.rows.item(Reg)['fechaFactura'];
				var fechaLimiteDePago = result.rows.item(Reg)['fechaLimiteDePago'];
				var numeroFactura = result.rows.item(Reg)['numeroFactura'];

				alert(numeroFactura);

				if (fechaFactura == "") 
				{
					setFechaFactura();
					setNumeroFactura();
				}

				else
				{
					document.getElementById('txtFechaFact').innerHTML = "Fecha Facturación: <b>" + fechaFactura + "</b>";
					document.getElementById('txtFechaFactura').value = fechaFactura;

					document.getElementById('txtFechaLimiteFact').innerHTML = "Fecha Limite de Pago: <b>" + fechaLimiteDePago + "</b>";
					document.getElementById('txtFechaLimiteDePagoFactura').value = fechaLimiteDePago;

					document.getElementById('txtNumeroFactReal').value = numeroFactura;
					document.getElementById('txtNumFact').innerHTML = "Factura #: <b>" + numeroFactura + "</b>";
				}

				cargarDatosEmpresaFact();
				cargarDatosPeriodoFact();
				
				var ConsuMedio = result.rows.item(Reg)['ConsumoMedio'];
				var ConsumoMes = result.rows.item(Reg)['Consumo'];
				var EdadAcueducto = result.rows.item(Reg)['EdadAcueducto'];
				document.getElementById('txtEdadAcueducto').value = EdadAcueducto;

				if (ConsumoMes > 0) 
				{
					liquidacionFactura(ConsumoMes,VolumenAseo,IdUsotx,categoria,idUsuario,NumeroCuentasAcueducto,NumeroCuentasAlcantarillado,NumeroCuentasAseo,EdadAcueducto);
				}

				else
				{
					liquidacionFactura(ConsuMedio,VolumenAseo,IdUsotx,categoria,idUsuario,NumeroCuentasAcueducto,NumeroCuentasAlcantarillado,NumeroCuentasAseo,EdadAcueducto);
				}

				var fechaLectura = result.rows.item(Reg)['Fecha'];
				document.getElementById('txtFechaFinalFact').innerHTML = "Fecha de Lectura: <b>" + fechaLectura + "</b>";

				var fechaInicial = result.rows.item(Reg)['UltimaFechaDeFacturacion'];

				document.getElementById('txtFechaInicialFact').innerHTML = "Fecha Inicial: <b>" + fechaInicial + "</b>";
			}

			else
			{
				console.log('if2');
				desactivarImpresionFact();
				$("#datos-entrada").hide();
				$("#datosGenerales").hide();
				$("#LecturaNoDiligenciada").show();
			}
		});
	});	
}

function liquidacionFactura(Consumo,Aseo,Uso,Categoria,IdUsuario,NumeroCuentasAcueducto,NumeroCuentasAlcantarillado,NumeroCuentasAseo,Edad)
{
	var consumo = parseInt(Consumo);
	var consumoBasico;
	var consumoComplementario;
	var consumoSuntuario;
	var vertimientoBasico;
	var vertimientoComplementario;
	var vertimientoSuntuario;
	var cargoVariableAseo;
	var aseo = parseFloat(Aseo);
	var uso = Uso;
	var categoria = Categoria;
	var idUsuario = IdUsuario;
	var numeroCuentasAcueducto = parseInt(NumeroCuentasAcueducto);
	var numeroCuentasAlcantarillado = parseInt(NumeroCuentasAlcantarillado);
	var numeroCuentasAseo = parseInt(NumeroCuentasAseo);
	var textoLiquidacion = document.getElementById("detalleLiquidacionFactura");
	textoLiquidacion.innerHTML = "<li><b><div class='row'>DETALLE:</div></b></li><li><b><div class='row'><div align='center' class='col col-center col-33'>Descripcion</div><div align='center' class='col col-center col-10 liquidacion'>Can.</div><div align='center' class='col col-center liquidacion'>Vr. Unit.</div><div align='center' class='col col-center liquidacion'>Vr. Cons.</div><div align='center' class='col col-center liquidacion'>Vr. Acum.</div></div></b></li>";

	document.getElementById('totalAcueducto').value = 0;
	document.getElementById('totalAlcantarillado').value = 0;
	document.getElementById('totalAseo').value = 0;
	document.getElementById('totalSubsidiosAportes').value = 0;
	document.getElementById('subTotalPresente').value = 0;
	document.getElementById('subTotalAcumuladosAnteriores').value = 0;

	var EdadAcueducto = Edad;

	dbShell.transaction(function(tx) 
	{ 	
		tx.executeSql("select * FROM CargosFacturacion",[], 
		function(tx,result)
		{
			var IdCargoFijoAcueducto = result.rows.item(0)['IdCargo'];
			var NombreCargoFijoAcueducto = result.rows.item(0)['NombreCargo'];
			var tarifaCargoFijoAcueducto = parseFloat(result.rows.item(0)['Tarifa']);
			var tarifaCargoFijoAcueducto2 = tarifaCargoFijoAcueducto.toFixed(2);
			var valorCargoFijoAcueducto = tarifaCargoFijoAcueducto * numeroCuentasAcueducto;
			var valorCargoFijoAcueducto2 = valorCargoFijoAcueducto.toFixed(2);

			var nombreCargoFijoAc = NombreCargoFijoAcueducto.substr(0,13);
			var mensajeCargoFijoAcueducto = "<li><div class='row'><div class='col col-33'>"+nombreCargoFijoAc+"</div><div class='liquidacion col col-10' align='center'>"+numeroCuentasAcueducto+"</div><div class='liquidacion col' align='right'>"+tarifaCargoFijoAcueducto2+"</div><div class='liquidacion col' align='right'>"+valorCargoFijoAcueducto2+"</div>";

			mostrarAcumuladosAnteriores(IdCargoFijoAcueducto,idUsuario,mensajeCargoFijoAcueducto);

			//-------------------------------------------------------

			if (consumo <= 20) 
			{
				consumoBasico = consumo;
				consumoComplementario = 0;
				consumoSuntuario = 0;
			}

			if (consumo > 20 && consumo <= 40) 
			{
				consumoBasico = 20;
				consumoComplementario = parseInt(consumo) - 20;
				consumoSuntuario = 0;
			}

			if (consumo > 40) 
			{
				consumoBasico = 20;
				consumoComplementario = 20;
				consumoSuntuario = parseInt(consumo) - 40;
			}

			var IdConsumoBasico = result.rows.item(1)['IdCargo'];
			var NombreConsumoBasico = result.rows.item(1)['NombreCargo'];
			var tarifaConsumoBasico = parseFloat(result.rows.item(1)['Tarifa']);
			var tarifaConsumoBasico2 = tarifaConsumoBasico.toFixed(2);
			var valorConsumoBasico = consumoBasico * tarifaConsumoBasico;
			var valorConsumoBasico2 = valorConsumoBasico.toFixed(2);

			var NombreConsumoBasicoAc = NombreConsumoBasico.substr(0,13);
			var mensajeConsumoBasico = "<li><div class='row'><div class='col col-33'>"+NombreConsumoBasicoAc+"</div><div class='liquidacion col col-10' align='center'>"+consumoBasico+"</div><div class='liquidacion col' align='right'>"+tarifaConsumoBasico2+"</div><div class='liquidacion col' align='right'>"+valorConsumoBasico2+"</div>";

			mostrarAcumuladosAnteriores(IdConsumoBasico,idUsuario,mensajeConsumoBasico);

			//-------------------------------------------------------

			var IdConsumoComplementario = result.rows.item(2)['IdCargo'];
			var NombreConsumoComplementario = result.rows.item(2)['NombreCargo'];
			var tarifaConsumoComplementario = parseFloat(result.rows.item(2)['Tarifa']);
			var tarifaConsumoComplementario2 = tarifaConsumoComplementario.toFixed(2);
			var valorConsumoComplementario = consumoComplementario * tarifaConsumoComplementario;
			var valorConsumoComplementario2 = valorConsumoComplementario.toFixed(2);

			var NombreConsumoComplementarioAc = NombreConsumoComplementario.substr(0,13);

			if (consumoComplementario > 0) 
			{
				var mensajeConsumoComplementario = "<li><div class='row'><div class='col col-33'>"+NombreConsumoComplementarioAc+"</div><div class='liquidacion col col-10' align='center'>"+consumoComplementario+"</div><div class='liquidacion col' align='right'>"+tarifaConsumoComplementario2+"</div><div class='liquidacion col' align='right'>"+valorConsumoComplementario2+"</div>";

				mostrarAcumuladosAnteriores(IdConsumoComplementario,idUsuario,mensajeConsumoComplementario);
			}

			else
			{
				mostrarOtrosAcumuladosAnteriores(IdConsumoComplementario,idUsuario,NombreConsumoComplementarioAc);
			}

			//-------------------------------------------------------	

			var IdConsumoSuntuario = result.rows.item(3)['IdCargo'];
			var NombreConsumoSuntuario = result.rows.item(3)['NombreCargo'];
			var tarifaConsumoSuntuario = parseFloat(result.rows.item(3)['Tarifa']);
			var tarifaConsumoSuntuario2 = tarifaConsumoSuntuario.toFixed(2);

			var valorConsumoSuntuario = consumoSuntuario * tarifaConsumoSuntuario;
			var valorConsumoSuntuario2 = valorConsumoSuntuario.toFixed(2);

			var NombreConsumoSuntuarioAc = NombreConsumoSuntuario.substr(0,13);

			if (consumoSuntuario > 0) 
			{
				var mensajeConsumoSuntuario = "<li><div class='row'><div class='col col-33'>"+NombreConsumoSuntuarioAc+"</div><div class='liquidacion col col-10' align='center'>"+consumoSuntuario+"</div><div class='liquidacion col' align='right'>"+tarifaConsumoSuntuario2+"</div><div class='liquidacion col' align='right'>"+valorConsumoSuntuario2+"</div>";

				mostrarAcumuladosAnteriores(IdConsumoSuntuario,idUsuario,mensajeConsumoSuntuario);
			}

			else
			{
				mostrarOtrosAcumuladosAnteriores(IdConsumoSuntuario,idUsuario,NombreConsumoSuntuarioAc);
			}

			//-------------------------------------------------------	

			var IdCargoFijoAlcantarillado = result.rows.item(4)['IdCargo'];
			var NombreCargoFijoAlcantarillado = result.rows.item(4)['NombreCargo'];
			var tarifaCargoFijoAlcantarillado = parseFloat(result.rows.item(4)['Tarifa']);
			var tarifaCargoFijoAlcantarillado2 = tarifaCargoFijoAlcantarillado.toFixed(2);

			var valorCargoFijoAlcantarillado = tarifaCargoFijoAlcantarillado * numeroCuentasAlcantarillado;
			var valorCargoFijoAlcantarillado2 = valorCargoFijoAlcantarillado.toFixed(2);
			var nombreCargoFijoAl = NombreCargoFijoAlcantarillado.substr(0,13);

			var mensajeCargoFijoAlcantarillado = "<li><div class='row'><div class='col col-33'>"+nombreCargoFijoAl+"</div><div class='liquidacion col col-10' align='center'>"+numeroCuentasAlcantarillado+"</div><div class='liquidacion col' align='right'>"+tarifaCargoFijoAlcantarillado2+"</div><div class='liquidacion col' align='right'>"+valorCargoFijoAlcantarillado2+"</div>";

			mostrarAcumuladosAnteriores(IdCargoFijoAlcantarillado,idUsuario,mensajeCargoFijoAlcantarillado);

			//-------------------------------------------------------

			var IdVertimientoBasico = result.rows.item(5)['IdCargo'];
			var NombreVertimientoBasico = result.rows.item(5)['NombreCargo'];
			var tarifaVertimientoBasico = parseFloat(result.rows.item(5)['Tarifa']);
			var tarifaVertimientoBasico2 = tarifaVertimientoBasico.toFixed(2);
			var valorVertimientoBasico = consumoBasico * tarifaVertimientoBasico;
			var valorVertimientoBasico2 = valorVertimientoBasico.toFixed(2);

			var NombreVertimientoBasicoAl = NombreVertimientoBasico.substr(0,13);
			var mensajeVertimientoBasico = "<li><div class='row'><div class='col col-33'>"+NombreVertimientoBasicoAl+"</div><div class='liquidacion col col-10' align='center'>"+consumoBasico+"</div><div class='liquidacion col' align='right'>"+tarifaVertimientoBasico2+"</div><div class='liquidacion col' align='right'>"+valorVertimientoBasico2+"</div>";

			mostrarAcumuladosAnteriores(IdVertimientoBasico,idUsuario,mensajeVertimientoBasico);

			//-------------------------------------------------------

			var IdVertimientoComplementario = result.rows.item(6)['IdCargo'];
			var NombreVertimientoComplementario = result.rows.item(6)['NombreCargo'];
			var tarifaVertimientoComplementario = parseFloat(result.rows.item(6)['Tarifa']);
			var tarifaVertimientoComplementario2 = tarifaVertimientoComplementario.toFixed(2);

			var valorVertimientoComplementario = consumoComplementario * tarifaVertimientoComplementario;
			var valorVertimientoComplementario2 = valorVertimientoComplementario.toFixed(2);

			var NombreVertimientoComplementarioAl = NombreVertimientoComplementario.substr(0,13);

			if (consumoComplementario > 0) 
			{
				var mensajeVertimientoComplementario = "<li><div class='row'><div class='col col-33'>"+NombreVertimientoComplementarioAl+"</div><div class='liquidacion col col-10' align='center'>"+consumoComplementario+"</div><div class='liquidacion col' align='right'>"+tarifaVertimientoComplementario2+"</div><div class='liquidacion col' align='right'>"+valorVertimientoComplementario2+"</div>";

				mostrarAcumuladosAnteriores(IdVertimientoComplementario,idUsuario,mensajeVertimientoComplementario);
			}

			else
			{
				mostrarOtrosAcumuladosAnteriores(IdVertimientoComplementario,idUsuario,NombreVertimientoComplementarioAl);
			}

			//-------------------------------------------------------	

			var IdVertimientoSuntuario = result.rows.item(7)['IdCargo'];
			var NombreVertimientoSuntuario = result.rows.item(7)['NombreCargo'];
			var tarifaVertimientoSuntuario = parseFloat(result.rows.item(7)['Tarifa']);
			var tarifaVertimientoSuntuario2 = tarifaVertimientoSuntuario.toFixed(2);

			var valorVertimientoSuntuario = consumoComplementario * tarifaVertimientoSuntuario;
			var valorVertimientoSuntuario2 = valorVertimientoSuntuario.toFixed(2);

			var NombreVertimientoSuntuarioAl = NombreVertimientoSuntuario.substr(0,13);

			if (consumoSuntuario > 0) 
			{
				var mensajeVertimientoSuntuario = "<li><div class='row'><div class='col col-33'>"+NombreVertimientoSuntuarioAl+"</div><div class='liquidacion col col-10' align='center'>"+consumoComplementario+"</div><div class='liquidacion col' align='right'>"+tarifaVertimientoSuntuario2+"</div><div class='liquidacion col' align='right'>"+valorVertimientoSuntuario2+"</div>";

				mostrarAcumuladosAnteriores(IdVertimientoSuntuario,idUsuario,mensajeVertimientoSuntuario);
			}

			else
			{
				mostrarOtrosAcumuladosAnteriores(IdVertimientoSuntuario,idUsuario,NombreVertimientoSuntuarioAl);
			}

			//-------------------------------------------------------	

			var IdCargoFijoAseo = result.rows.item(8)['IdCargo'];
			var NombreCargoFijoAseo = result.rows.item(8)['NombreCargo'];
			var tarifaCargoFijoAseo = parseFloat(result.rows.item(8)['Tarifa']);
			var tarifaCargoFijoAseo2 = tarifaCargoFijoAseo.toFixed(2);
			var valorCargoFijoAseo = tarifaCargoFijoAseo * numeroCuentasAseo;
			var valorCargoFijoAseo2 = valorCargoFijoAseo.toFixed(2);
			var nombreCargoFijoAs = NombreCargoFijoAseo.substr(0,13);
			var mensajeCargoFijoAseo = "<li><div class='row'><div class='col col-33'>"+nombreCargoFijoAs+"</div><div class='liquidacion col col-10' align='center'>"+numeroCuentasAseo+"</div><div class='liquidacion col' align='right'>"+tarifaCargoFijoAseo2+"</div><div class='liquidacion col' align='right'>"+valorCargoFijoAseo2+"</div>";

			mostrarAcumuladosAnteriores(IdCargoFijoAseo,idUsuario,mensajeCargoFijoAseo);

			//-------------------------------------------------------	

			var IdCargoVariableAseo = result.rows.item(9)['IdCargo'];
			var NombreCargoVariableAseo = result.rows.item(9)['NombreCargo'];
			var tarifaCargoVariableAseo = parseFloat(result.rows.item(9)['Tarifa']);
			var tarifaCargoVariableAseo2 = tarifaCargoVariableAseo.toFixed(2);
			var valorCargoVariableAseo = aseo * tarifaCargoVariableAseo;
			var valorCargoVariableAseo2 = valorCargoVariableAseo.toFixed(2);
			var aseo2 = aseo.toFixed(2);

			var NombreCargoVariableAs = NombreCargoVariableAseo.substr(0,13);
			var mensajeCargoVariableAseo = "<li><div class='row'><div class='col col-33'>"+NombreCargoVariableAs+"</div><div class='liquidacion col col-10' align='center'>"+aseo2+"</div><div class='liquidacion col' align='right'>"+tarifaCargoVariableAseo2+"</div><div class='liquidacion col' align='right'>"+valorCargoVariableAseo2+"</div>";

			mostrarAcumuladosAnteriores(IdCargoVariableAseo,idUsuario,mensajeCargoVariableAseo);

			//-------------------------------------------------------

			var totalAcueducto = valorCargoFijoAcueducto + valorConsumoBasico + valorConsumoComplementario + valorConsumoSuntuario;

			document.getElementById('totalAcueducto').value = totalAcueducto;

			var totalAlcantarillado = valorCargoFijoAlcantarillado + valorVertimientoBasico + valorVertimientoComplementario + valorVertimientoSuntuario;

			document.getElementById('totalAlcantarillado').value = totalAcueducto;

			var totalAseo = valorCargoFijoAseo + valorCargoVariableAseo;

			document.getElementById('totalAseo').value = totalAcueducto;

			var subTotalPresente2 = totalAcueducto + totalAlcantarillado + totalAseo;

			document.getElementById('subTotalPresente').value = subTotalPresente2;

			//-------------------------------------------------------

			var IdSubsidioCargoFijoAcueducto = result.rows.item(10)['IdCargo'];
			var NombreSubsidioCargoFijoAcueducto = result.rows.item(10)['NombreCargo'];

			mostrarIndicesSubsidiosAportesConsumo(IdSubsidioCargoFijoAcueducto,uso,categoria,idUsuario,NombreSubsidioCargoFijoAcueducto,valorCargoFijoAcueducto);

			//-------------------------------------------------------

			var IdSubsidioConsumoBasico = result.rows.item(11)['IdCargo'];
			var NombreSubsidioConsumoBasico = result.rows.item(11)['NombreCargo'];

			mostrarIndicesSubsidiosAportesConsumo(IdSubsidioConsumoBasico,uso,categoria,idUsuario,NombreSubsidioConsumoBasico,valorConsumoBasico);

			//-------------------------------------------------------

			var IdSubsidioCargoFijoAlcantarillado = result.rows.item(12)['IdCargo'];
			var NombreSubsidioCargoFijoAlcantarillado = result.rows.item(12)['NombreCargo'];

			mostrarIndicesSubsidiosAportesConsumo(IdSubsidioCargoFijoAlcantarillado,uso,categoria,idUsuario,NombreSubsidioCargoFijoAlcantarillado,valorCargoFijoAlcantarillado);

			//-------------------------------------------------------


			var IdSubsidioVertimientoBasico = result.rows.item(13)['IdCargo'];
			var NombreSubsidioVertimientoBasico = result.rows.item(13)['NombreCargo'];

			mostrarIndicesSubsidiosAportesConsumo(IdSubsidioVertimientoBasico,uso,categoria,idUsuario,NombreSubsidioVertimientoBasico,valorVertimientoBasico);

			//-------------------------------------------------------

			var IdSubsidioCargoFijoAseo = result.rows.item(14)['IdCargo'];
			var NombreSubsidioCargoFijoAseo = result.rows.item(14)['NombreCargo'];

			mostrarIndicesSubsidiosAportesConsumo(IdSubsidioCargoFijoAseo,uso,categoria,idUsuario,NombreSubsidioCargoFijoAseo,valorCargoFijoAseo);

			//-------------------------------------------------------

			var IdSubsidioCargoVariableAseo = result.rows.item(15)['IdCargo'];
			var NombreSubsidioCargoVariableAseo = result.rows.item(15)['NombreCargo'];

			mostrarIndicesSubsidiosAportesConsumo(IdSubsidioCargoVariableAseo,uso,categoria,idUsuario,NombreSubsidioCargoVariableAseo,valorCargoVariableAseo);

			//-------------------------------------------------------

			var IdAporteSolidarioAcueducto = result.rows.item(16)['IdCargo'];
			var NombreAporteSolidarioAcueducto = result.rows.item(16)['NombreCargo'];

			mostrarIndicesSubsidiosAportesConsumo(IdAporteSolidarioAcueducto,uso,categoria,idUsuario,NombreAporteSolidarioAcueducto,totalAcueducto);

			//-------------------------------------------------------

			var IdAporteSolidarioAlcantarillado = result.rows.item(17)['IdCargo'];
			var NombreAporteSolidarioAlcantarillado = result.rows.item(17)['NombreCargo'];

			mostrarIndicesSubsidiosAportesConsumo(IdAporteSolidarioAlcantarillado,uso,categoria,idUsuario,NombreAporteSolidarioAlcantarillado,totalAlcantarillado);

			//-------------------------------------------------------

			var IdAporteSolidarioAseo = result.rows.item(18)['IdCargo'];
			var NombreAporteSolidarioAseo = result.rows.item(18)['NombreCargo'];

			mostrarIndicesSubsidiosAportesConsumo(IdAporteSolidarioAseo,uso,categoria,idUsuario,NombreAporteSolidarioAseo,totalAseo);

			//-------------------------------------------------------

			for (var i = 19; i < result.rows.length; i++) 
			{
				var IdOtrosCargos = result.rows.item(i)['IdCargo'];
				var NombreOtrosCargos = result.rows.item(i)['NombreCargo'];
				var NombreOtrosCargos2 = NombreOtrosCargos.substr(0,13);

				mostrarOtrosAcumuladosAnteriores(IdOtrosCargos,idUsuario,NombreOtrosCargos2);
			}

			sumarAcumuladosAnteriores(idUsuario);
		});
	});
}

function sumarAcumuladosAnteriores(IdUsuario)
{
	var idUsuario = IdUsuario;
	var sumarAcumulado = 0;
	var textoPieDePagina = document.getElementById("pieDePaginaFactura");
	dbShell.transaction(function(tx) 
	{ 	
		tx.executeSql("select * FROM AcumuladosAnteriores where IdUsuario=?",[idUsuario], 
		function(tx,result)
		{
			if (result.rows.length > 0) 
			{
				for (var i = 0; i < result.rows.length; i++) 
				{
					var ValorAnterior = result.rows.item(i)['ValorAnterior'];
					var valorAcumulado = parseFloat(ValorAnterior);
					sumarAcumulado = sumarAcumulado + valorAcumulado;
				}

				document.getElementById('subTotalAcumuladosAnteriores').value = sumarAcumulado;
				var sumarAcumulado2 = parseInt(sumarAcumulado);
				var mensajeSubTotalAcumuladosAnteriores = "<li><div class='row'><div class='col col-50'>Sub Acum. Anterior:</div><div class='col' align='right'><b>$ "+sumarAcumulado2+"</b></div></div></li>";
				textoPieDePagina.innerHTML = mensajeSubTotalAcumuladosAnteriores;
				cargarPieDePagina(sumarAcumulado);
			}

			else
			{
				textoPieDePagina.innerHTML = "";
				cargarPieDePagina(0);
			}
		});
	});
}

function cargarPieDePagina(AcumuladosAnteriores)
{
	var AsubTotalPresente = parseFloat(document.getElementById('subTotalPresente').value);
	var AtotalSubsidiosAporte = document.getElementById('totalSubsidiosAportes').value;
	var AtotalSubsidiosAportes = parseFloat(AtotalSubsidiosAporte);
	var subTotalAcumuladosAnteriores = parseFloat(AcumuladosAnteriores);
	var subTotalAcumuladosAnteriores2 = subTotalAcumuladosAnteriores.toFixed(2);

	var totalAPagarPresente = AsubTotalPresente + AtotalSubsidiosAportes;
	var totalAPagarPresente2 = parseInt(totalAPagarPresente);
	var AtotalAPagar = totalAPagarPresente + subTotalAcumuladosAnteriores;
	var AtotalAPagar2 = parseInt(AtotalAPagar);

	document.getElementById('totalAPagar').value = AtotalAPagar;

	var textoPieDePagina = document.getElementById("pieDePaginaFactura");
	var mensajeSubTotalPeriodo = "<li><div class='row'><div class='col col-50'>Sub Total Periodo: </div><div class='col' align='right'><b>$ "+totalAPagarPresente2+"</b></div></div></li>";
	textoPieDePagina.innerHTML += mensajeSubTotalPeriodo;

	textoPieDePagina.innerHTML += "<li><br></li>";

	var mensajeTotalAPagar = "<li><b><div class='row totalAPagar'><div class='col col-50'>TOTAL A PAGAR:</div><div class='col' align='right'>$ "+AtotalAPagar2+"</div></div></b></li>";
	textoPieDePagina.innerHTML += mensajeTotalAPagar;

	textoPieDePagina.innerHTML += "<li><br></li>";
	var EdadAcueducto = document.getElementById('txtEdadAcueducto').value;

	var mensajeEdadAcueducto = "<li><div class='row'><div class='col col-50'>Edad Acueducto: </div><div class='col' align='left'><b>"+EdadAcueducto+"</div></div></b></li>";
	textoPieDePagina.innerHTML += mensajeEdadAcueducto;
	textoPieDePagina.innerHTML += "<li><br></li>";

	mostrarCodigoDeBarrasFactura();
}

function mostrarCodigoDeBarrasFactura()
{
	var numeroFactura = document.getElementById('txtNumeroFactReal').value;
	$("#codigoDeBarrasFactura").JsBarcode(numeroFactura,{format:"CODE128",displayValue:true,height:35});
}

function mostrarIndicesSubsidiosAportesConsumo(IdCargo,Uso,Categoria,IdUsuario,NombreCargo,Consumo)
{
	var idCargo = IdCargo;
	var idUsuario = IdUsuario;
	var nombreCargo = NombreCargo.substr(0,13);
	var uso = Uso;
	var categoria = Categoria;
	var consumo = Consumo;
	dbShell.transaction(function(tx) 
	{ 	
		tx.executeSql("select * FROM IndicesSubsidiosAportes where IdCargo=? and IdUso=? and IdCategoria=?",[idCargo,uso,categoria], 
		function(tx,result)
		{
			if (result.rows.length > 0)
			{
				var indice = parseFloat(result.rows.item(0)['Indice']);
				var indice2 = indice.toFixed(2);
				var subsidio = consumo * indice;
				var subsidio2 = subsidio.toFixed(2);
				var consumo2 = consumo.toFixed(2);

				if (subsidio2 < 0) 
				{
					var subsidio3 = subsidio2 * (-1);
					var subsidio3Fixed = subsidio3.toFixed(2);
					var subsidio4 = "("+subsidio3Fixed+")";

					var mensajeSubsidio = "<li><div class='row'><div class='col col-33'>"+nombreCargo+"</div><div class='liquidacion col col-10' align='center'>"+indice2+"</div><div class='liquidacion col' align='right'>"+consumo2+"</div><div class='liquidacion col' align='right'>"+subsidio4+"</div>";
				}
				else

				{
					var mensajeSubsidio = "<li><div class='row'><div class='col col-33'>"+nombreCargo+"</div><div class='liquidacion col col-10' align='center'>"+indice2+"</div><div class='liquidacion col' align='right'>"+consumo2+"</div><div class='liquidacion col' align='right'>"+subsidio2+"</div>";
				}

				mostrarAcumuladosAnteriores(idCargo,idUsuario,mensajeSubsidio);
				sumarSubsidios(subsidio);
			}

			else
			{
				mostrarOtrosAcumuladosAnteriores(idCargo,idUsuario,nombreCargo);
			}
		});
	});
}

function sumarSubsidios(valor)
{
	var subsidio = valor;
	var acumulado = parseFloat(document.getElementById('totalSubsidiosAportes').value);
	var suma = subsidio + acumulado;
	document.getElementById('totalSubsidiosAportes').value = suma;
}

function mostrarAcumuladosAnteriores(IdCargo,IdUsuario,Mensaje)
{
	var idCargo = IdCargo;
	var idUsuario = IdUsuario;
	var mensaje = Mensaje;
	var textoLiquidacion = document.getElementById("detalleLiquidacionFactura");
	dbShell.transaction(function(tx) 
	{ 	
		tx.executeSql("select * FROM AcumuladosAnteriores where IdCargo=? and IdUsuario=?",[idCargo,idUsuario], 
		function(tx,result)
		{
			if (result.rows.length > 0) 
			{
				var ValorAnterior = result.rows.item(0)['ValorAnterior'];
				var valorAcumulado = parseFloat(ValorAnterior);
				var valorAcumulado2 = valorAcumulado.toFixed(2);
				var mensajeFinal = mensaje + "<div class='liquidacion col' align='right'>"+valorAcumulado2+"</div></div></li>";
				textoLiquidacion.innerHTML += mensajeFinal;
			}

			else
			{
				var mensajeFinal = mensaje + "<div class='liquidacion col' align='right'></div></div></li>";
				textoLiquidacion.innerHTML += mensajeFinal;
			}
		});
	});
}

function mostrarOtrosAcumuladosAnteriores(IdCargo,IdUsuario,NombreCargo)
{
	var idCargo = IdCargo;
	var idUsuario = IdUsuario;
	var nombreCargo = NombreCargo;
	var textoLiquidacion = document.getElementById("detalleLiquidacionFactura");
	dbShell.transaction(function(tx) 
	{ 	
		tx.executeSql("select * FROM AcumuladosAnteriores where IdCargo=? and IdUsuario=?",[idCargo,idUsuario], 
		function(tx,result)
		{
			if (result.rows.length > 0)
			{
				var ValorAnterior = result.rows.item(0)['ValorAnterior'];
				var valorAcumulado = parseFloat(ValorAnterior);
				var valorAcumulado2 = valorAcumulado.toFixed(2);
				var mensajeFinal = "<li><div class='row'><div class='col col-33'>"+nombreCargo+"</div><div class='liquidacion col col-10' align='center'></div><div class='liquidacion col' align='right'></div><div class='liquidacion col' align='right'></div><div class='liquidacion col' align='right'>"+valorAcumulado2+"</div></div></li>";
				textoLiquidacion.innerHTML += mensajeFinal;
			}
		});
	});
}

function asignarCausalFact(codCausal)
{
	dbShell.transaction(function(tx) 
	{ 	
		tx.executeSql("select * FROM Causales where IdCausal=?",[codCausal], 
		function(tx,result)
		{
			var nombreCausal = result.rows.item(0)['NombreCausal'];
			document.getElementById('txtCausalFact').innerHTML = "Causal: <b>" + nombreCausal.toUpperCase() + "</b>";
			document.getElementById('txtLecturaActualFact').innerHTML = "<b>NO SE PUDO REALIZAR LECTURA</b>";
		});
	});
}

function asignarObsFact(codObs)
{
	dbShell.transaction(function(tx) 
	{ 	
		tx.executeSql("select * FROM Observaciones where IdObservacion=?",[codObs], 
		function(tx,result)
		{
			var nombreObservacion = result.rows.item(0)['NombreObservacion'];
			document.getElementById('txtObservacionFact').innerHTML = "Observación: <b>" + nombreObservacion.toUpperCase() + "</b>";
		});
	});
}

function cargarDatosEmpresaFact()
{
	dbShell.transaction(function(tx) 
	{ 	
		tx.executeSql("select * FROM Parametros",[], 
		function(tx,result)
		{
			var nombreEmpresa = result.rows.item(3)['ValorParametro'];
			var nitEmpresa = result.rows.item(4)['ValorParametro'];

			document.getElementById('txtNombreEmpresaFact').innerHTML = "<b>" + nombreEmpresa.toUpperCase() + "</b>";
			document.getElementById('txtNitEmpresaFact').innerHTML = "NIT: <b>" + nitEmpresa + "</b>";
		});
	});
}

function cargarDatosPeriodoFact()
{
	dbShell.transaction(function(tx) 
	{ 	
		tx.executeSql("select * FROM Periodos",[], 
		function(tx,result)
		{
			var idPeriodo = result.rows.item(0)['IdPeriodo'];
			var nombrePeriodo = result.rows.item(0)['NombrePeriodo'];

			document.getElementById('txtNomprePeriodoFact').innerHTML = "Periodo: <b>" + nombrePeriodo.toUpperCase() + "</b>";
			document.getElementById('txtNumeroPeriodoFact').innerHTML = "Id Periodo: <b>" + idPeriodo + "</b>";
		});
	});
}

function setFechaFactura()
{
	var date = new Date();
	var d  = date.getDate();
	var day = (d < 10) ? '0' + d : d;
	var w = date.getMonth() + 1;
	var month = (w < 10) ? '0' + w : w;
	var yy = date.getYear();
	var year = (yy < 1000) ? yy + 1900 : yy;

	var fecha = day + "/" + month + "/" + year;

	document.getElementById('txtFechaFact').innerHTML = "Fecha Facturación: <b>" + fecha + "</b>";
	document.getElementById('txtFechaFactura').value = fecha;

	mostrarFechaLimitedePago(15,fecha);
}

function mostrarFechaLimitedePago(d,fecha)
{
	var Fecha = new Date();
	var sFecha = fecha || (Fecha.getDate() + "/" + (Fecha.getMonth() +1) + "/" + Fecha.getFullYear());
	var sep = sFecha.indexOf('/') != -1 ? '/' : '-'; 
	var aFecha = sFecha.split(sep);
	var fecha = aFecha[2]+'/'+aFecha[1]+'/'+aFecha[0];
	fecha= new Date(fecha);
	fecha.setDate(fecha.getDate()+parseInt(d));
	var anno=fecha.getFullYear();
	var mes= fecha.getMonth()+1;
	var dia= fecha.getDate();
	mes = (mes < 10) ? ("0" + mes) : mes;
	dia = (dia < 10) ? ("0" + dia) : dia;
	var fechaFinal = dia+sep+mes+sep+anno;
	document.getElementById('txtFechaLimiteFact').innerHTML = "Fecha Limite de Pago: <b>" + fechaFinal + "</b>";
	document.getElementById('txtFechaLimiteDePagoFactura').value = fechaFinal;
}

function setNumeroFactura()
{
	var idbd = document.getElementById("idOperario").value;
	var noFactura;
	dbShell.transaction(function(tx) 
	{ 	
		tx.executeSql("select * FROM Usuarios where Id=?",[idbd], 
		function(tx,result)
		{
			noFactura = result.rows.item(0)['UltimoNoFactura'];

			var largo = noFactura.length;
			var trozo1 = noFactura.substr(-7,7);
			var largo1 = largo-8;
			var trozo2 = noFactura.substr(0,largo1);
			var nuevoNumero = parseInt(trozo1)+1;
			var nuevoNumeroString = nuevoNumero+"";

			while (nuevoNumeroString.length < 7)
			{
				nuevoNumeroString = "0"+nuevoNumeroString;
			}

			var nuevoNumFactura = trozo2+nuevoNumeroString;

			document.getElementById('txtNumeroFactReal').value = nuevoNumFactura;
			document.getElementById('txtNumFact').innerHTML = "Factura #: <b>" + nuevoNumFactura + "</b>";
		});
	});
}

function activarImpresionFact()
{
	$("#imprimirFact i").removeClass("disable");
	$("#imprimirFact").attr('onClick', 'imprimirFactura()');
}

function desactivarImpresionFact(){
	$("#imprimirFact i").addClass("disable");
	$("#imprimirFact").attr("onClick", "");
}

function imprimirFactura()
{
	guardarDatosFacturaUsuariosServicios();
}

function guardarDatosFacturaUsuariosServicios()
{
	var txtNumeroFactReal = $("#txtNumeroFactReal").val();
	var txtFechaFactura = $("#txtFechaFactura").val();
	var txtFechaLimiteDePagoFactura = $("#txtFechaLimiteDePagoFactura").val();
	var numero = $("#txtNumRegistro").val();

	dbShell.transaction(function(tx) 
	{  
		tx.executeSql("Update UsuariosServicios set numeroFactura=?, fechaFactura=?, fechaLimiteDePago=? where Numero=?",[txtNumeroFactReal,txtFechaFactura,txtFechaLimiteDePagoFactura,numero], 
		function(tx, result)
		{
			guardarNumeroFacturaUsuarios();
		});
	});
}

function guardarNumeroFacturaUsuarios()
{
	var txtNumeroFactReal = $("#txtNumeroFactReal").val();
	var idOperario = $("#idOperario").val();
	dbShell.transaction(function(tx) 
	{  
		tx.executeSql("Update Usuarios set UltimoNoFactura=? where Id=?",[txtNumeroFactReal,idOperario], 
		function(tx, result)
		{
			console.log("guardado");
		});
	});
}