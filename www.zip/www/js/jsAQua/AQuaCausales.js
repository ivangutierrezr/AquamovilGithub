//Cargar Causales

function cargarCausales(entrada)
{	
	var reader=new FileReader(entrada);
	
	reader.onloadend=function(evento)
	{
		var causal=evento.target.result;
			
		dbShell.transaction(function(tx) 
		{   
			tx.executeSql("select Count(*) as Cantidad from Usuarios  ",[], 
			function(tx, result)
			{				
				var tipoArchivo = typeof result.rows.item(0)['Cantidad'];
				if(1 == 1)
				{
					var Control = causal.match(/\n/g);
					for(var i = 0; i < Control.length; i++)
					{						
						var UltimoDato = causal.indexOf('\n') // Se determina que ";" es salto de linea
						var Dato = causal.substring(0,UltimoDato);
						var SepararDato = Dato.split(","); // Se determina que cada dato a incluir en la BD se separa con ","
						
						tx.executeSql("Insert Into Causales (IdCausal, NombreCausal, exigeObservacion, exigeFoto, Numero) Values(?,?,?,?,?)",[
							SepararDato[0],
							SepararDato[1],
							SepararDato[2],
							SepararDato[3],
							i]);
						
						causal=causal.substring(UltimoDato+1,causal.length); 
						causalesSubidas = i+1;
					}
					swal("Cargue Realizado con éxito", "Cargadas " + causalesSubidas + " Causales", "success");

					confimarCausales();
				}
			});
		});
	};
	reader.readAsText(entrada);
}



// device APIs are available
//
function Causales() {
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFSCausales, fail);
}

function gotFSCausales(fileSystem) {
    fileSystem.root.getFile("AQuaMovil/Entradas/Causales.csv", null, gotFileEntryCausales, fail);
}

function gotFileEntryCausales(fileEntry) {
    fileEntry.file(gotFileCausales, fail);
}

function gotFileCausales(file){
    cargarCausales(file);
}

/*----------------------------------------------------------------------------------*/

//Función para borrar las causales de la base de datos

function borrarCausales()
{
	dbShell.transaction(function(tx)
	{
		tx.executeSql("Drop Table Causales");
		CrearTablaCausales();
		Causales();
	});
}


/*----------------------------------------------------------------------------------*/

//Funcion para Saber la cantidad de causales registradas

function ConsultaCausales()
{ 
   	dbShell.transaction(function(tx) 
	{    		
		tx.executeSql("select  Count(*) as Cantidad  from UsuariosServicios Where CausalActual<>'' ",[], 
		function(tx, result)
		{
			 CantidadCausal=result.rows.item(0)['Cantidad'];
		});
	});		
}


/*----------------------------------------------------------------------------------*/
// Verifica que la causal exija foto u observación

function verficarFotoCausal()
{
	var idCausal = document.getElementById("txtCodCausal").value;
	document.getElementById("txtCausal").value = document.getElementById("txtCodCausal").value;
	dbShell.transaction(function(tx) 
	{
		tx.executeSql("select * from Causales Where IdCausal=? ",[idCausal], 
			function(tx, result)
		{
			var exFoto = result.rows.item(0)['exigeFoto'];
			var exObs = result.rows.item(0)['exigeObservacion'];

			if(exFoto == "TRUE" || exFoto == "true" || exFoto == "True" || exFoto == "1" || exFoto == "VERDADERO" || exFoto == "verdadero" || exFoto == "Verdadero" || exFoto == "si" || exFoto == "SI" || exFoto == "Si")
			{
				swal({
					title: "Atencíon!",
					text: "Esta Causal Requiere una foto de evidencia, debe tomar una antes de continuar",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#0088C4",
					confirmButtonText: "Foto",
					cancelButtonText: "Volver",
					closeOnConfirm: true,
					closeOnCancel: false},

					function(isConfirm)
					{
						if (isConfirm) 
						{
					  		FotoCausal();
					  	}

					  	else 
					  	{	
					  		swal("Cancelado", "", "error");   
						} 
					});
			}

			else
			{
				verficarCausal();
			}
		});
	});
}


function verficarCausal()
{
	var idCausal = document.getElementById("txtCodCausal").value;
	dbShell.transaction(function(tx) 
	{
		tx.executeSql("select * from Causales Where IdCausal=? ",[idCausal], 
			function(tx, result)
		{
			var exFoto = (result.rows.item(0)['exigeFoto']).toUpperCase();
			var exObs = result.rows.item(0)['exigeObservacion'];

			if(exObs == "TRUE" || exObs == "true" || exObs == "True" || exObs == "1" || exObs == "VERDADERO" || exObs == "verdadero" || exObs == "Verdadero" || exObs == "si" || exObs == "SI" || exObs == "Si")
			{
				swal("Atención","Esta causal requiere Observación","warning");
				document.getElementById('txtCausal').value = document.getElementById('txtCodCausal').value;
				validarObservacion();
			}
			else
			{
				ActualizarArchivo();
			}
		});
	});
}