angular.module('starter.controllers', [])

.controller('MapCtrl', function($scope, $ionicLoading, $ionicModal) {
  $scope.mapCreated = function(map) {
    $scope.map = map;
  };

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/mapa.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeMap = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.openMap = function() {
    $scope.centerOnMe();
    $scope.modal.show();
  };

  $scope.centerOnMe = function () {
    console.log("Centering");
    if (!$scope.map) {
      return;
    }

    navigator.geolocation.getCurrentPosition(function (pos) {
      console.log('Got pos', pos);
      $scope.map.setCenter(new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude));
      $scope.marker = new google.maps.Marker({
      position: new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude),
      map: $scope.map
  });

    }, function (error) {
      alert('Unable to get location: ' + error.message);
    });
  };
});
